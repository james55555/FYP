/*
 * Function to prompt the user to confirm their action choice
 */
function confirmAction(item){
    return confirm("Are you sure you want to delete " + item + "?");
}