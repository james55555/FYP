Final Year Project
This project looks to create a Time Management System for Professionals managing small to medium sized projects.

The system is being designed using RUP and will be designed using four iterations, each advancing in complexity.

The code has been designed using the model-view-controller architecture situated under the include/ namespace.

@author:	James Graham
@module:	CS3010
@owner:		Aston University