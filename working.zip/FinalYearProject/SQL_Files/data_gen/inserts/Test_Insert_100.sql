
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('Mjdb3AgCSFN53a','08.13.01 06:10:00','jlYVUz7s7CK0vdE4No2rHEyZQV0o6Zz6erizWyRntjIubj4bZyEKynTeoZiw2QbQnxxa0CstOlRSxevyh050gHq2dRFSx3CYOAuDuUEx','oPyP0WUJcBE5X0euTCw3FVqQZq28G6','pwqDY0AxtrsmEnHVQx6Na3I0FhswZ','R.Heyn@libero.be');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('3tku2XTIAv','03.24.13 01:01:00','J6pYtc8y4rDCqCdYGwjfvXccFaC5YOG0VNoeKBFauFWVJVbrUvcYWrUYtJ3b7hZsZLp7pQZSXRaHAT3sJMLNGwRoJNRVWTjr1uLL4H4ED1XdrnMettKKwHIXOBeMYiLVgdYQeIJgDT0bniPFnECvtA5cedXvXwqHHul5tHY3q','Knqc8epkI','03CvK3YnMsb8NZwXrjF3gSh','Richard.Moon@telfort.co.uk');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('R6crLEoZsbHU2wNZpPe','03.17.14 03:06:00','UYteShx4EfHZmQAfeDROm5JrLvDNYPpIhfxEirji7nQj7HVoEgJy4RdioaI01TU7M7RkPUXBPcqYVyXVcBqIfGVJ354QHQDkL1lkxyoQ6u5gNaYhnLF5KIyMJXOfXlY1nr6fm4NaflJIhBXBzmggDq0kFktnsn6nkVqXGuQ0eiFiIsV3MmXc3XwUmZeUzxcF3vmPJRK','Sz','8','Leo.Anderson3@weboffice.be');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('zxFJ','07.11.10 02:55:00','LGCsYh1','YtSk4J2ULFLNJRzu4HCk3zc','ZHvLrzzE1Nj3nsfURhAJeu','H.Scheffold@gawab.fr');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('krKujUoz465','05.08.13 00:17:00','lJzaXkZ8V4wmMlQ52AP8gzJvQe75BSVZH4xf5nuEAXDYLVaqT87uIEMr2PB6NNiBBlqAfKVdxWIlyH4QQulfg3odapzSqSJnsGdiJ7QUT1prdZYnSMV3az2X6T5KsmZoDQeGRzIUQuYA6FibhJ4VlXnWLW2OXS8MjJVt0jDrkzQfZ7Qi3NcTFLMXNwe6JEIFOs7juZpZtNbXSaPDEe2HkyQ6nvqhIur5chziAr','7PuPOpOippXF7mr','emZrlWPO','TCain1@mobileme.net');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('3','05.09.07 05:43:00','ugTtNtjlEBKSfWiBI0pMfUlceWgT61EXqJvH5Hd0eN3YaSMSqOmkf7H2BlohrGxJCO66DRAo7mRpzaRJx6SsfMDbI3xwdhwuV','C3Cd6','fDKnCwRGmZdu4i6yQRVqyUqV2pLpQ','Jakevan Goes@gawab.us');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('D1qI25jjN','10.26.03 05:39:00','p7cmnx582b4bspRLP3huYG4Ub6aprgn2RTKOrM5zFv1SIWZgFcVdIIPvPUq72HSM4SkKeyPLxzUYYbouR3hTzxF3mAu6ySst7j1seKqb2rX2V1y4Kt7w7td5S','SlIygQ','70joFLavvY2rP0vG01KteH1uECS',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('G5IXst4yIUtyMr35IhbVQQJ','12.23.05 09:47:00','3VGgZDonFnRDDTyMx4drPO3K0llDjCdRUfJUoWpP2eIWsxfKrSkoQHXbF0YIX042ksy7IenWSXkBFTcK4W7bt0QGkZMkfeLLxnLCOp4gU54Meynsr0Xd34TcpN62hjXDfYhe1gzNgnqwenhA6f3VEWeNOnLLuJsl2irFvmKAsQki85MnY1EgmGKtJfzUHJdIJBxlqILPXXMj0WudwugmOYDAPYslYNqfcrqA5dRxhA73hBqFo','Xr2H','Yf5qmV1Vl7xC1','Victor.Praeger4@telfort.org');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('maUT5smHETlOQSZOxVBCt','11.26.10 00:06:00','bbLUugMFI0bjHIe376uDZAZlCOFfy8lWKwJ5dhccJXNshTtQSWQaxHoURLbo4jP54YmNMSmJ41ONQ0eS3nyu7xUXofUSIDJFEObMop8HjNA','thoG0g7EH4KlupcaY','n','William.Ayers5@kpn.fr');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('v0S2','09.13.04 05:49:00','hYOVRGWV6qioGsrzJ','s','fvM4HcLjO20HFY46GAIJT','FransAnthony@excite.es');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('5iLIeaKB0VJTneWY','07.12.12 02:22:00','bwvp4SvXA4mmrK8WSaddkYXoJVUwKXi3YadF51ggyKawnKiCrvsaw8D7zbRdhfu3B5pbkfur0tbfBfDzOcTKXQn1CwCIXv0kyXpQRW7UQ5JEFTMsZRNOpRsHocY5UrPEgQoLNIYY2paOGYlOhUBgF4XKe4jYsBG0da43RApc4WcY1NBSMDweAGD0HpwKJCL2eIcvnM64CEdDFGlYvlqquV8TMchsxLPq1UaxnHXD','JsRJ15TL','g7pYXU3Z03JuhJ2','Hans.Pyland2@freeweb.it');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('Ia3w7iC2RaYUpUvNmgtZ','04.05.03 10:57:00','k7vePbzU7qybP58d70fD5uvaaLrpFJM1EkJFaIsetl8YswiGRAzrJMW65hJn5h25IaORAWg5V5iYMcc03whUPZRzbg0PBPlYYOr00Vm6thUINgIt3g2RuetQV5fKVjbragnNm2Sge248Ee8E1szwfOB5K4weW71qeV7tjDIni0FWrgxgqSJ8EXo44ia7cW1XWFje4Q0R','R','K5cDRgiv3MPc3YZhdyYM','JohanCragin5@telefonica.fr');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('eG','01.17.00 04:36:00','jkiBq3DK3BvQUhtKq4oMbc6DqlSCV81sSS1FfKwzvW1OeTuKwWZMiKRNBmnwf2LYTWWAdBYsahYu6','GU3nGqzuG0cZn','FOQ1MNXPjlnsGbVsZL2gM4WP5D0N','FransHoyt5@aol.net');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('IYYSTCI','02.07.08 01:40:00','rqg34R3S18Jcmhr42oon','k','SbWJWTaDVtknatqRJqOcNPqPqmf','Nick.Linhart3@freeweb.dk');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('mK','11.26.06 00:00:00','5FCr5gSDIrDVcYWlGXIkYe5pVSo7D','w5RlkUr8206aF2yyWFtHWZ5vKVo','djI8njerUiXQTTuC63fI4In','WBeckbau2@web.no');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('g7bp7bL8XhbyJDxm4f','08.22.05 08:43:00','dIqJwaEFPWdrJKqph6GhH7CguhLcQzHU7gw3SZB5Z21RhaMHz2pA4ZCCkhbxYk5dQ7aYqJkUsB3l4OypJu2PKK3oMPFGVNBYwbSBAh8dZqitdHGIevKNwyjxG5X4oY8cs5bhWaPGBIH4XvIdqjliUFOfrjlvI4jejVznvLzEiZtHYWM0sipxDHySCXaNlGTgP5y7BK8i6aiXUCGGuqDUv7Jor2PMMxDents07Qe6qK5kofjikBM2P0Bn','byPVPJ46K5rZKnjnE','6','L.Langham@gmail.ca');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('LoEBnjABewXLmyYHK1','06.10.02 07:09:00','ktiyoxbT8agZsVz8SxeL3g1eaC2JimT0WjfAPD','NlBz','4RXsVdZIY4NI',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('1VwdWZQgCXC3SWhQQ4ip','05.08.03 09:07:00','kLwCkC1knzNuY4Wyw0tgi54zJ1Kpwx3as65QeaZMGgZNhk3mR4Gh5LJRe','3jAehfsJMcY05yKGSUxl5qbxzSmKg','8qliMp','UGerschkow5@telfort.cc');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('RYNPgbK','10.08.00 10:23:00','H5xPd11t7emzB617uYv7TBfHjYzfwNM10FImwmKKCGSn4vl4xCSAl1ivGecm2RfNXvN4oM1rtbU1ksfxSd6uyKwtHMit7XE6uPp32Crkru6FHtODYQ3N3W80iGHcRASnXOwZOva2A4JFgK8uLVRHLGlonQuTw1ErZdWbhobJouS5UL6BrkspcmOFIlTMOmSKfo7vqoaNMoUSRGGHYGtzTaSWjS5','Uen3WLDVZBjVWXz0mryEavHN','3Y423PBGE5y188ckyDbbM06tv','RKepler@mail.no');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('HNm6URomtRyGozlcYZHRrgIwN','02.21.05 10:17:00','kKpQJ6mYIEpVsFYnQEzqqVpxm2gJkaOiiIxdkwxZQU8MLFvtAg3L4wsc1hKaHOR8fleDu4woHnZfoZ2HA2DC5G40GHjUidGQBWlhJMbWZe6t5uFRAZ5V7HwUrZDLjKdmIHTgM8zCop8HncVDhcA8orgQfCl1EkVCO5lmYS2FjstWTHyaHAKlXCcwl2JdCPZjmEZh26d','Rbf62CVrbOLfbNkon68t7B1YoXpMx','m7oZz14M','BrentPyland@mail.be');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('qwOPfw','10.25.02 05:38:00','g3QMVmTwrrHPJ8oRCgHtIlNshKAb8hU46076JzCX6E5gnvO6zSQxr8u3Z4rJOWYuFJ44UasgchpOOK8kZiliZTxJhDT2YMqJ8uTtVB0UQGUMbQh1oYNT1Avgt1aKPRjT6vyLeE0Wdy4BHCSQ','aXONYq7n2yWyvrA0Qjj5BjSRt5BC','C5CyrWwBrpfr443cIvc20rgMrx6zM','LPhelps2@excite.net');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('jqEgXv0rWIsQnb7MEK7aCu','08.17.11 06:37:00','wz8TavBsUT5A0rUCAjUW4jqUBg6wIszaMudOlXDOwyuxTr3ouDytB0a8uYWb1Gf0aspB06e6TQhXgZXIxmCxAUqxr2lNmQiZj3rsqVA1qJWtE5bW73bwLnUv0s5aAlIkK8X08adNvM4dy88Z7ZcsFHyXEw11kH3cxWVfqtshsFqLT0JNUNLeM','WfA0Xd5IRlgDhBkOgIV','s7FeRYoQh8BSXxZ7meERE5','Peter.Depew@excite.es');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('l','03.24.09 06:05:00','rUahHttIJoTV8xA4TPhkrKqxtSQRvnvHdZ6L5oTXMVv7nYDMJUwx1mE','0xmkGEWUoqezVOTKgRvsjR1','G','William.Yinger@telfort.cn');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('4EI6iLzR38kT3Kuz','06.26.03 08:03:00','zeVNwCkXSYUxWt2DTzfZUEZ4tE73cwztj1fa7hyPXGuSzUVibswYD','G4teooEEKTQ','w3lHkF0icLFObVfyG0Xqh','I.Brisco5@mail.cc');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('u','06.03.03 02:26:00','fGL4X5wiHVyEZJCRpeoUU7JFhy7P4XKxkvPeIldNkMefifowqap4LfBaqs06','MjP0Sen','Kuejg4J586tQstS1pY8nZ8','H.Clark4@myspace.fr');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('0y','04.05.12 10:43:00','KA1qzokbK0spCqKzsXy85dOojpTk0lsATXyGSCC2kcIf07OZtCpWjMx6mfBrFugDBva88twMcVjxl4bwglvPsZBLevyYxCFyXA7FXLEM0bhl1eMVBn6oxvj8BmchVqAcq5H6bEF3Lyseq','oDnQIRTs8Ln7TqO71DSyB2YeaQMDD','12i5rqyGLLvjnmfF3','Jack.Arden@web.de');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('d','01.21.13 07:12:00','cIprh8BvgY2vc0efBcxJmoeDrZqmewj','8','fs7U','Kim.Krutkov@gmail.no');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('z04K7','02.25.08 04:02:00','E5DSpJXyv0WSeTpt4Fruuh1DHBwB0nv0pnBEKe5AUdMwsSVMGsyCqMJqqRduv2sBFnldj8xsv5hU4hw02OYoy44M7jIHFVMSCq0mpeMjavW3QlLvaAqTlshAx6IVk5XxnvSGQUT3Lzucd8mVogHpnuOEW6IopEekbKtQ8ST3vjVU70hVnY6zMw0cyhV0cNn6DcaaQlpL2d5ALBqfSYLo3','kM','bWOhNdtwGfkpn5AGL2i','Hank.Hardoon@aol.org');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('Skuf1TIzUAEYRi2olIWb','10.18.07 05:00:00','LNORozLnXRgkwAuPNQ6kkwBfQK1Vry','2EJGeQCNuNxPrGnoPPunZ1dcKC1An','7qIZEWROpd08','E.Aldritch@freeweb.be');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('tZdI3bsT0tXNorDU','07.17.05 10:38:00','4ualIgSGcSr8WUliOCmhciEH7Rl8u8v6EpreZhfMcG6oxTTIF33Pf7fZC2LfRt6VmjvW0SK0XG4sVRPnrcT7q6abIFLiaA5MIKx8eSzhqukaM3OdgJ746UT8ix8R83yhR30DynKXMiPoIAWhQG1mNt2fFpbuVBy6FnP1leeEcEYpyXpOCim5wBW8F4wVIQSSl1NLSW0D4PthLqO6ayUYR2KT3aablxkGUpSJYRg0xTcOXxUqbLMHZcLs','7xLoEFxjfJMr0G8S4Ls','iNr8lHR3t5VfifHjogP','BasWong@dolfijn.com');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('ps','04.26.03 08:13:00','nhuEG3kkIwLo6tUatzibl70PJjaMZImv1pMLjUo4KK57Ob5Oi7EmqS1rjC','ad4roEZx0AIxgd2suRO0tDKr5WnW','h7sv1sZ4rML6e','JDelRosso5@libero.es');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('YALFdo','03.23.12 06:32:00','ZlFUHw3nE2GAOkhPS87mUEzyjGn08KVDF1sroWwwZcy0s7zrLaSHhJnF0jiYNj4nMDdbHQ7z5v47EMC6TFcZCRc2tc2s0i','baO4UB','fRT4xHW7RmCZa','T.Bertelson@gmail.cn');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('pBM0OtMSFQ','04.28.09 08:58:00','kr5YMu6tFvf4HQNVkzWmzFMY0M2kQq5uHoKk8FetcUzrERQN73mAzFo4RJ51CTMnxbCm7g3fSDkqb67KhqJQIWUuBydkumoulmqNslKOUKr7iDzdK1Fgcy8bkE0BC1z6sLVHb5VpxpU0sEqITZuIvdKynJeT6oYhdJ3QF2GylXAv3UvYcHvsAuyOLwMdHAGZoSGCxUuWVKr5ErxbSGsgcXKo3rzTZBlZcFZHf0evjSHN1nD8aUZtkLnfHMQZN','XtXMcbxID7fmd','4rDFRtJlxgop0CarQz8e3aybt2fbgR','IGriffith@dolfijn.gov');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('oBNaovzJmc0mKR0EwWoBvVeO','10.20.11 06:58:00','fSDZbqVkeXwghMlClWLDP2McxBSDZuzXRPsY64ZzePNaAB1VRZpdXvSj7L8sh2yysihNNJC5WiIzHZg5g1ZXvtNL1jaE8DrCLEZAAZ4ARC4Fpo2y6gnyWY17wZPrKFMjwJergonCnjD0WHeHSiWzcNlgENDltQZRSB6H7SD7OXkW1aAFBKKBLB3CcFHzTFX0AJCdmRhJnBWGIOaWFymaD0G04Hq8kwFcDufFTXyEQz','Tb5ur0fklvrZZEV17IRC','qKWkEtsMgDnZsU','WMeterson@myspace.gov');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('IC','10.04.02 03:15:00','zpUriG2KZbRQu6UJCu','rOCvz','heLwgq8t6FPzPJIhF30p','SBitmacs@msn.nl');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('g4J0TyhPGOOO2lDP','05.26.03 01:06:00','b2gm8h1tXfH71o0tjgSlhrRuQ1OHXVZL2AhlIkealjcEiLKKS8AWHWCdyHAxoLB8GIenPcGyydLLz8mXYNNySnblA2eh','brsc4qEpHlAx4OvwOntIHxo4h','K1Mrq1doTw1','Bas.Shapiro@hotmail.nl');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('1vmfeOZm0lFelzJcqR','10.26.01 01:51:00','LS4STzmn5qx8XhR17a6YcOLGAM0fTkR2yl7dB7udl3gyedOM6usoiUIYLGfzaWxeZdjrSe6VVqg4lAir1xCtXVDeDVNWQel24sP4edSzRAyiwGXdP3xo5Ok1LmetwIbnP6','hVHDbLkpTKJm4FJP5MSCyCeC0J','7mWtygrlQeu8TtMuQME','Nick.Freeman@mymail.us');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('UHJd31Xw2UJTQxCU6Vu','05.01.02 10:22:00','NQyYHd5r6GxdhfPPTgbrOUoVz8Pe1cDW8CvNwTMyTe1zJUosEimKgZzmebjZ54Ycfuhjr8hTMzDapbTOyx0YxhXrOuPaGAhh5TRIEqgQiamC8bfvyYRdXbnkuguixZr8LZx0','cucaYus5oDivyIwj2QwI7QWDG0','zzArJgE',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('QYPpdVoqi0','10.16.06 09:32:00','VsuFFmTInPUxbpB6fIpirSAonZipb0dNx7uM3stE2uhe5k5TnrhCaHRimwMUp8uSERUtSQiabTC6RjlmF7gQ4nSmvwAw3qvdgzPA3s','6aSfiuKwL2dOCH3DSoD','0HmIG2dTt0fQjhBxWk','Nadine.Swaine3@excite.net');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('pwWcsUa4rYL3VSTYuoG','01.29.00 03:58:00','GKqvIj','VtMkSC6S6EZ6','xz0ofNCIdVGTRDKdYCNk3V6zg',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('E4K','10.25.11 09:00:00','7DZnkuoKQctaRFfMYEysvRkaLjBrDXxBUre6FdLGlyqllOJEGsrJgJm5yJ7Cmsd2Nfpa0WgOaKGO2Uz26nwCYcj2R402gAhtFbzYop26EKcqk','o','0HC2b3wQXTod1bgRA8Q','Bill.Yinger2@mail.us');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('HIBu7SXMrFLvduF','12.27.11 07:30:00','uOp7QvZY','7sS0os6cUWZJrbo7aHFf','ZmWBVAJ2HerQq3','Lynn.Fernandez@libero.cc');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('EqFmfAlm4TPtKUbcYMsLMDdGK','10.09.03 02:07:00','kTGsY8wyHWl1sBLFh65XQuhp56zSGCHzK32QoZdZl6saCTTw1FVxgdFn2KKR65GnNvYcjkPppZ34IcuFkN3xU2CHGUOmS8XJKohkpCaWopOAqX4btzHP5dk6vwmrh8LF5tHyxGG2pAFUW7YZzEnnvYbbf5fwjNbnFAjwPZnepPet2rUqGhh','7Uwzvrz10hZBQJmN','ixPeJrYo0BigfkfskJxwgQi5V5QE6','Lindsy.Zimmerman@telefonica.no');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('xyXojKGREuLoSdn','01.29.12 04:40:00','YbUjjY22Lnq67umeaoLFlUCO2ZJPAsStqcasFasGXBCbxhycUzfObNgePjuwD','i','AtpecCU2yrCWjtxOPmNMbiNiDjMlDX','VBernstein@yahoo.es');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('JCmp7bNdagCi7qXsgIF','04.17.02 00:10:00','8syvZjHXiJiQB8wR7kHHEEwRKbXQWSZ63wxy4NYpbrejCZL6S8NTU141DM0r1wBnIFgdJWnSGN5JF7dtyENSvNWt6fDUsfmdpsr4Q5BfGI4qhPsdR7QCuAQtw2nmGzncpOOqmPmcV8yIXxyTqY6kG56sZEYb2cxKtctNByfXetICXea7wC','r5rveK','vo4zA3AMnzJDQRt5QsfmmWr',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('IJPkDaLcYspk','01.26.14 05:33:00','N','3s71nTiOOKKANISAg','SNnEVzH3Ok5PXbZzLetcVaBBh6UrL','FransWolpert@gawab.cn');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('z','12.07.11 07:45:00','64re5u83wRThlnMD4kxg5rOhVLTcur5xmEsPA','5KxOCiwz','AGZtGBGwzLL1t8FrGO','Annvan Dijk3@lycos.be');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('hPScAu','03.13.04 01:50:00','IzIPjRWtXSUlpeotKLoouZt2GcQ1F7drdJHetXoIVPf6foBMWDCER075WMbUCxiyiU1LA86xKU4cpNP4dHJIYb7YbH2u58voBhGsik0e5ALKOuMlguv','tSNxQIZxo16rBb77FS48E','PZblHaMfHoCDWNy','RWooten@kpn.ca');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('ToO5LbdXYcSZuV2z','06.26.05 04:53:00','uz8q28DkB0h0bOfSnMOC4tRYt7uJCoDzqFVn5q8fxrmhNNUiwfrTXrCMToMyh27teuoutZU0rNBVfV3Id3erSGDbasjUOtBFEdPbkIMn0Xxb2zQJXEiMWuwnjWe0CimDdwhlwwVHCR6ke8wTg6RsK1hNdz4kMlMV2u32aeDpeDLp3dQw162khK7aPsVnJSqw1PNruL06o0NtSydRDOKfmDiFfEIhdNFxs','3','ATn0KNmEkILgibN87','Brend.Beckbau2@web.us');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('Rk4SU','03.17.06 06:05:00','DgNa8hhCLUXWspf4E70qT1vuOX6dNaTu5XnQKFNZRHAbKuZlKuF1Vtr','f0PvQfWa4o','0m3z3o56mJ2M5EWBvB4','Bianca.Seibel3@mail.it');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('RXry7WrwWssqiuZ','10.28.06 09:05:00','WswcQZM8pJwiNqcyAEKLDXt022UEh8KDQYLY5QP3i5Ys7FKFiTROELMAyF2dDqGorxpWKR5c2uz2Qt4ns3Au8GYj46r1Gr0XRsgY3IFBcP6JyICdvWtnLMMWTgnmcZ0isRS3M85blkfWEPu6SCLlhgtgVcDtg4g4yGKD63PLEUslK','KGkIuEvU6vLAHmAFO6TyLYBtN','bip','Ann.Guyer@gmail.it');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('n5yVyrZZxjoWy','03.08.02 01:04:00','RlOlKALMpzkLuWeqbjWwlrVMRh71izNXMZvZL8w7KDjsHCNtqvRytozQzEOLJrMvZbwSlnhoqH8p1vDCUvAtyRDXPNXBFSxvTVJUNSVw5BXeye4zj1iOPja05YBh56At7umY7CFOQYjdEQlPurlPitwqyCcon4rWUwuyDxWMmxS64wYpbHhDEZ2GH6nRPojfrNAg7tYdN1jOaiQbwr8SLEpTWWnkCr6V5nAxRyXoG0ufD0ugQym6s','VbuXpYt85husJjMMZb1eviUa','QTjxRROEbnQ1wcegW7svv',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('H0','01.09.12 05:16:00','TbJGnRQ6QXtipJss50Ywwbx3QHWTsrxI7f62fLdRSw3I7l8scKp13OfXRdMZfsYHJZXdhma8PMHYJS2G052RdPEc65KtDXFTnRtvMd8DIya3uxBwwpdd5OiBFFyFSKVo6GmXhsA2x1gGvimOYJu4tuTT5gtZV3XTndVcS6pSQEJNqApcdOiaQgps30ZHaducMZZG5Tp47bbY7xgzwYl8ZE54g2sNun','jASzBa','kxJlp4ANF',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('7s','05.29.01 00:36:00','MOJbfoHy1rWyjISeo4lAOuPHuMYOmOQ6T7NanVV3fr2QVd4e8Iqy7o1aK0h7nn75C','0qIVKZo35XKZKva7EO','qkuvcDo6biR1O','DavidBright@telefonica.dk');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('ePk7Cvaya3kZ3pz3Sf','10.28.01 09:38:00','Ardhzr4usgh5f8L0LmVpAiTJ','lcGkmuv6xVBkHsf6qV5Y0Z','CXdBy7P','Y.Pyland@gawab.co.uk');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('SUVT5PPNKTePPmf','03.16.10 03:11:00','4B3qnay4UDIrb','ZyWsCXInHHe5MKnPE6E0Ib4IevLao','PK4T2rKrm8DvVAXVGvOm4TjGUy43F','Vincent.Browne@myspace.us');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('18CqFEqEz0R0PrexhIID','08.19.08 03:12:00','y2Ol2NYJGCySho5eCwM4gIVUkgG0GZDI4AmwpU4P6C4qqd2WXksaag2uA5nfafxTx0bGhggobDF7WQlmRNqGX4YMZ2LpQubwGakbjpKUfUFxq10Tw7ukJ6KwTMZ4hvyTgonjwhZGhjsvn57mRtG0QTZDpunlLxbUnvxvub1yCdEVPvFp7IjofU5cUAPEfD12UDiH1dBuAhYXBdYNF410e3NP3XwtxhXSeJsoWdxKr6l4OB3VSN1','DkwnaHbd6E32lRxGLKQA7','GcS5ZDe28jYu','VWalker@telefonica.org');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('MoL5ZycMfaLjzOwSAyi3vaq','04.05.12 07:40:00','VSIK6CuqhLS4TsC3IrsJowHI4ogo2siVJLFka1ii2yV5QZC5Xkb247iWeKF1tIiyyOMqCYpmLxwVQzHVtIdHNsfb5cLj0JB1zle5wpTJWfXoLlQBN5qdQ3rtwvuBOIKafWUVxlYtFdlVgFFiMBThTbXPF3gusI3NrZ33zWDi3UZJOBQMcVFgq1OnuNb5EFuDOsylBocLCge6eXY4rVBfpJXmFVHdVxIf4rzPM4j','Ky6VH7s','o5G3lu','Dana.Ecchevarri@libero.fr');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('taX2seGxrbpDuOd','11.10.09 05:19:00','DrW4TCgfm07u4aTSOK7WhRa3BeLbxgKKbdr2jFNM15QSBJ6VL','mkzrVAoxBnz071CZjfF','KlNV','Johan.Pearlman2@myspace.dk');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('hWEpxk','02.26.12 04:53:00','HGu0QDQzcM1vb6ZEwuvSo5qwn1Wlojhrzvg7702u7OXlEF3tuxpqJVO1vymZquJ5GFZGgCSWAxn44AWE7Id1Oaf0vUYd7Cl7JWBXGzAg84NjxFoEeGj0QjnrlOtlFge4LtgjGWfkH1siNkGx60LN6b6O1mSmo6XwliUbHkln8ON3eUPXHGF001ivEpZPiej8gOXUa77k7gaVyqc5v5Hd0fTQxGhIKia4AFKcSZMHE30DH3zEY2pcG3uJnDrVS','rWZ8ZFT4NstWP','6wZnMwe6wPxwmAfE8NzAjU3Qx3jQpA','EFrega3@weboffice.fr');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('53K2','04.19.13 10:12:00','OGz1tY17Sp55MM165BzuhItjYDfyeMUjU2hhkU5G2g4geISgO5nkoSxcsSDx6zYhFyfuzYrpKXCCn4XzXoVJXfgDPXaGngExpvglNHNkGQv7c6X','ltaGsT7','TtsK4jsfNmaaVSRukrwayTsN','Milan.Dittrich4@libero.fr');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('CDmr22Ij4IBEvd3MdR','02.07.11 04:41:00','8Ja7wmKUkOwhcRSPjAMntKA6eGFMYSbIgAAf08hY1iYVsaU4pqVGSFKynApVmqqXqHK4bsHaWSViq7HNmViv84eu5bBXUOVCDRFH7Xzd3maFfHEQnIsyRXeezf1M2gw16oQUk1f','p8cL65UH6Qd0DGCs','x7ok1o',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('v8qg6qho2','08.02.08 04:38:00','EflsdU77ztpJgyHrLWpt8B7JBL0KR2PoBfT8lO','uzMMEycvfWhDuwIrvidYunqEHmcHFg','Vm7oNQ4','Nick.Ratliff@hotmail.de');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('P','08.14.09 08:58:00','oUW','stFwARr88TxEPw','kobXuqJQTDj7IGkM2ORym','Johan.Mitchell@msn.cn');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('HYETRxloa8','04.13.06 08:00:00','K0tyYsPOxPKhapHyAsAI4h2cr1m0HfYLNKZ2RmPHgVPy250gTHTvW3HQmivPhuenhuOVR7WnAg0Yy1kOjnZPOSLTlVE2PEsKtoQe7gQ0vbnDA1uZADwTgl7owkuXZUAOtLcIqoGSLyHJfq0v5WoaeEgmovxzNFgCNFW6ufsHuENgNvYwRCyz7pjVYt136dTpJRrAl','3YjqA4kovgfc7vSeGg','BwygJpW','RogierTrainor@mail.gov');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('a','10.25.08 05:24:00','W1CeRqx5iGlVSVFvv3zPQVUyHrplAgo7u6QKR','MRzQPXmVLJUVFVBZdNsRx78U','xAX','RCramer@msn.nl');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('efGmDuOVTtCp','09.16.12 04:21:00','vkeigkdeekSnz3vrZNp2eyPmdFteUh4ImQUFlvkfBCveydSVsfsBQSE5DcMoh71wu4gUtOR60oxmueiSCNF8htU5z4MVZ5YQTZ12JsvcPTfmRbAcR1P3258NfINttq7F60koxvlF8PjZVEeERSyRLQ0pq2y3CjGdqlxoy6Rd2UvrtXBeokcqtIwSes','u2yxjcrwiwP6OLu4','CtONraDofrptbiAnMoyG4sbLuF','NickDean@telfort.ca');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('xdqPh7nTV','07.01.05 05:48:00','zxB2ZO5xl7WDRqRH8md6NG7Vpk7NmQOcVNMOCZdPRLKoklByRREodc7UtBVOCezywSERvfkZ2agRJIAbFYz3t1gKucv4N45wHirnDcnS7QjG8t0kPNJ1C2vbNXfR0EP0XtFkGPu76Oo','8CQ8DrsMKo','USJeIHAlXRT1','Pauline.Daniel1@mobileme.fr');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('58iyaQdqBg','04.23.09 04:46:00','yDMtbvBeGAYPqvWDY0sW31Uw7XAlqP5qBUjKVaKtyVRE7tvG25PyCyGXXKHiulKfuCP7Y5hOkbyarfbnIyYnXTPcXYH1ss4UydqWI5CLfIagX2G4HHVKxCOPBSLTevmcUfnHlCqmeRFOP1pQfDCfm2d13RwnvMCa6Zie','h6ooQRR7CGjXcmrveWxkA','lNlRGAas0tE7wtDXKx6B3SXfa',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('ODbEYbrgNFzEpkdCZM','01.09.14 06:18:00','wqVzkESSpiVPYaD13tCramvMkeXCkChkSzq8zK3BiBvRxPrjHwj54fhY3GHktqb8HZJfIOtUZzoKO6Ma3LNOZIw7zmXpzhPqoc6eNPXcP5xN1qnidOa6RojDRFPHY','qYCzF','IswrOOnbqMoW8wLDSDysLx6fsVCE',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('j3LLmL2Z7qC4vfTCFSoO7PJu0','10.28.07 01:56:00','VrI4Q5JpJ4jupmkMALQJx2rbdYJRvPhLn71knwPgfjB5BTg4WUsEkkytOkvOcANfUDEIFPgvNkjbOMWEvkQsAqmmLVUep5jotnnqt6VtSnkUEPttP6hgcbyv00AMCTxayklUW6FhxlUD5NquWakUIfcgBE86SuP3LtjAEMTunMJ5MD4VRkDIrZCSe0o','QUlLzs5gHzgpMy','0mqhdkc5vSDsWF','Freddy.Hendrix1@telfort.ca');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('VWyIIyj','07.16.03 03:17:00','sfDivH3wDebVIWoCdxkXRlQaYDf5LvvxKYEtPHEUR7GVCWI4NwwDfJIffXmJJyprOHMcCsLaxaRWJ67PVDvHxArhfYOWfGQ4dw5BFSwRt4U7NWpkgHx0r46gXr1ku1cZ5CueQ3InNCuNHRfIeIu1ufaAb1gEuURfC6NzMSmzeHaDNHKB1n6rLIRd1BsTtPBeYbLAo1Fic0xdNLTYahcYGOSmje1rVqG0JCUPtvyuK2VDjQ28i','0qdYiw4qiei1BhHAsS5nIezHWuLGP','JpswogRhnOcI3xvXIf','Sjorsvan der Laar3@dolfijn.be');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('Vi0xGIAvfXX','12.15.11 01:04:00','0eFM2oCk6aetyWZqkhRPuz46y2uoNYlZYntstyjhUHuoqKE1TOfdQo6US2VN5HZws1eJZVYeLnSgEJNNCWHCHeRgSPlaaGlEBb8efnpkEsKAY6c6nSp62MjTixxuenmLE1ExMBGLzmpxSj46MK6Xoy81BesQYy2yTkue0Z','hP7kEKJLfZW','DbuyttuL1qoNTnA','BasMayberry@lycos.fr');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('83dAlJ8','07.13.13 06:16:00','4rmneblFY3XJP2JSXphCQ5URtFNMpDTWWIQfb5Uoc6Vkzd33fOxHZdnESq5MSvcVXrtCzTtnMFKkkRe1KFWvnXkZfUJqLS3GiBNkyhWMTzUK4XP6Ndue0VSsR21o1ykG5LFE12QdWYkGewBnjVhRY7e4PqjuBUmgCQeHLIeAW6rk0fVx5AmyPnEEb4K0JP7FlhqNPVSn4A3M7dzGMPABdFyDx7qWt1','8bdtnjJKv5P4','bM7pucxamLbPADe7263s','K.Mayberry1@gawab.nl');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('ahfiR3ubejGkou','05.09.09 00:45:00','EvE7ospK5Mtv6o3KqaNXtxaNaKywJCLKUON4dCBleQBTkwi8az7IVz3tf3ZE8hpUs7RWYGBtfvwwZMwAR8fV1FR11IYIRv0Y67JCDbjnZ4SlDXCh4N6bfR8DS1fyTAZsJ3U7fdChN1LeBpOZNcvrVGtcBG2dqHXuKrC4','eTp','WBjNIP43yvvZZ0D','Rick.McDaniel2@kpn.ca');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('GG8cfPrgLkIv0XrCkTGJc7wA','02.26.08 05:45:00','eES3YCHaDsvT3qZLdlEwLgqxK8gNp8XojQe5EAK02jaHid3DkAvqVekRD','VVRy','CICX0HqKQecZMHlRMI1hC0','OliverPensec@hotmail.be');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('jD12WwLBwacV0SEc8d6jbNDHJ','09.27.09 07:14:00','cSkvcYWUgYXCvVdEphQXXWoCCCOLzMzWWIob7urgiakATLVhbQfflTGmRULHzFWAEVlhBmhZmTJvW0AFPadIhejHBamhKQRdMQRU7LN4VNebq2J5ARKi4DpFSFwck7GUk1r5Un8SKcOSWse1RFGUH4qbRMyOzDakXMrEA3lIneDXOAYFSzGA1FB0CnlpFxtDTbofzLLEMLLfKD02SR3l5D8rSBRoPAzfq2PPMRFrByYr','zZLvml0gLcM1bAd7UZurt','ulNV4BPXy','NickHoyt@gawab.fr');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('s4uufkZLsVyMG75U2','06.04.07 05:19:00','ViNu06EovgjNDtEsNyF6np6H0BQXNMrYnBDcA3BUXM0RsSLkzt32ftKcfgQw0ZojVMyA1Vn3MW3ERVLPHr7jsjkT8QYQhmOePDa5eNsv0','HYdz3LiQMbGBqgXAL','vf6zyivn3TQSfDIC6KIIP',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('Q','01.15.04 04:04:00','h2','jVKzZBMCIL8Of4Bxa','8GJVRZJ8hI4kYoQl87Wpev8q','Dick.Heyn1@mobileme.dk');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('iH8LTlIAwZFoW','03.23.07 03:22:00','HDMyTLKqbj7sOdGUschVrchWs5mTJwwPds0bBqVlKLptYPzxeCg1cPGG2HR8j8cToaRHMfbltwCHCCu3LnlEBJXDXHGC5cqYT1htB4oAkDsuSWikkC5YuzIHWnwPiIhpNIa1lz2ChWGauvf8xlphaLdsSFP0tdqRkkJKdgKR7LEYaE5ielvacBpUeGx1','t3tPuJmLpMcRaVRIMYfs6mqji7','Pr',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('belqr3IaQaZq4VVg','06.03.01 08:40:00','GV1MTloNq1vof2ORrxatroYtOFxvKlKU2VRVLOLcGpnIQNORWAsgFQUNsmvbx8YlzOHE1xQQ3V0AbEuTR17KAPvlF76cVoSW','5Q5ctmfTM5Kf5V7kbma','kEy5T','RichardPetrzelka2@yahoo.cn');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('w7Vg3luoKYB4MhROJ4Nlcf67i','03.24.05 04:01:00','we78zgSnjeZKAqApax6hvSyPo6TnW5iSJn6qNCY6SDhsGFuNaaMzg6RDRNR1iEsW1nAekwLcl8tslJNEMbNyJoO2j4LqdzBmJSsIfTvtfTvmjFGYJEB1U85yUkJtney3P4Kos08PrzWfVPmMUhlpIQI3rZqe7CwBaDZHZCEkdRLJFsCCm3WSPWX8m8QSJfRnWhYsTtuI1NVSyJzoF2yoEok44Y0oNFhRPL24qAAJwwbW33UpMrFMrD','hHGcLs3wh','j','R.Ionescu@libero.it');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('cbmhXTNYdwfakE','02.28.01 05:34:00','zbSmgeMpMFmCJxmHkcLZRpMrswujc4xzDwhyi5Qz50mNO0jXfz5I17MHlzBOGdkrhKgEUrx4UZbGgkNSDmurvbiTzLCtA4V1WYyuIHhhkbuooAQ7QsoKARS','xY','l2FhRx3D10hMSfBoMMR7yQPgl1Aj','LHoogbandt1@telefonica.dk');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('g4B370WMQXeVk','02.03.05 00:21:00','N5i','t7Gcl3l','eeu','RRay@libero.us');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('7aZAcwLVcDr2o7VyXs','04.16.05 04:34:00','fkOTv4WzIuxTgMJg3Smmd7zCcSZDm6kv0MyrWY0iOfwMIlvrReoIOuEZalA20CQHzrqoMEoo02P4T06YjmDZPbgQkXn5JAeiXzpkhAyLsjApqRaB6TDaZMZFFlmYWm1r2jJLUJAHgjUtKGb6JcgANIoDd6ZRxLcJV1ijVOSiHIDb4nT4rj','mZPH6MYl0kObfekjmlrpSiOq2H','8UyNfJF',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('FnP0V4WYSD7jkPqvu','11.23.09 01:31:00','6Tk0bo17UrGRqOAm0NrGSFzkn4hmePQMqQPRZr8PZ7bziSxeuG','xy2mXO','37woqhm0veeQZ50Oj7RU1nY','GPerilloux@libero.fr');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('XPH4','06.09.02 06:16:00','sk2tgTb6uoqGt41X1c3k4JmSM6PVaqFxN2JaDnvrt730sXxgtbJ1WAAxEdJCmUWIuUKvlx0oyZflveIHMrbEMWSrvUCdMyHmEjYgWdAKr7yUZlVjTNS7t6iqiGCLiChOSQjU','4HgJrCN8','fGFRSTuBdvepVHbkriTZCj',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('DoEsLoht05uyk','02.17.04 04:54:00','ctpc3NHcsUP6oxXAmEigAGGqiaiI7f1AR83sRpfHiAMz4uEuSKpofWNKlnE8pja','OrnAQAhfgZHvpAYLWkkGm5','1ZNvjmwswW4VMCOJqYxNQp2oqE',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('tfLKnM14','03.04.09 05:54:00','m7Fux5xknkVcEUh8UKuhzKEcGTS0ooUfEYhOiNXdShVhpBTgPDwLuJTc2SNTK0v6oJW2qSujhiXnstPaK7Smc3df7esgmMDdGTUQ5tEVkRrRgvyFTzpHgtOK2JVRM0Y7nSktBnamkorskJbzS6RWBvB0lZVC4Det0Qejvf0uRyovV8AG014hemWrYIxKrM5aHwFuhGmoZIK1YaAegXls','kgqEGO67uZZGfQdqj7sO3aJ','yrIBw83HUfCLMGjNwZuJR','Jim.Crocetti@dolfijn.com');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('811Ibs0X0HWiHKUeNRoi','12.23.07 10:23:00','KEyboqPTtlCXXCzlPTdTKQhTN2kOnVseaQhQuPQBDya2wOgdWIAsCnalfXgmSxIrOzJhyLqrzOlexxtbbD7o0TN7wpaP88Aa051iX1BAkcDRRwZvUYJ8XTWFzbgTsXCR5OIDYFv0rwncQfJzqRvV1nxO','CkW5beFO5LKl1abPuG','jj45Zd30kbZ8LP6Is','V.Leonarda@live.gov');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('ABLstp5fa2ID1W0JBqz8','04.10.07 10:41:00','get71frVOIbWwFFA8btWVQlnwwsFLE7K10IbWUGLGBnMjtoOZF1O8RSlS3jCsqsg3g','7PjydB','Rm4oCNN6VXyEX',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('ezVRyvn0veiVSaB5z2','03.12.13 00:04:00','LVjrG55wjxp1kWg3nRnqn6awZ3gDUY4wjlOf6OQkNliQbyzClQHQoK4uvLEx0nntVdnd4d3vlpHyjSZZ7juS31LxgRNXN8WcvBB6KJZdKXAU7yuLgXyQEuh3BlglN4JV83eVsenCQ6QcGfUaLshugjap3fcpzIf2UZHxVWkajYR5FTDuehPogQsnCjDm64KLX8YTFx2IvdBTmtOaSignp0wiemh5','Bl6lBFPRxGplHhr','VqUBmJulwbMHOsQ3','DickMillis4@aol.nl');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('huleSnUZfi7MdHZFAr','04.10.06 01:06:00','D8yE4bfciKv3ADP4SS02wsaCEXCizKzOA7dMCT7tpq0DatZu','Hy4NRI5Jlm2Urkvi0irk2qsBYkv0A','Q2td2etbeAW6',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('gztTcvg04jFKVlSy3KfNqjOP','08.22.00 08:30:00','njrlzGJtvcz7rJQSklmJ2Bj6FXDuHE2mQir30zJ6ct8KFB78G0lseFuYZv6SfrBm1yADPMAk5V','cjke','ErU1vVlZk','RichardHamilton@live.es');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('ZZVUzf3NLkaWPgTZaMgXW','05.23.09 02:02:00','36nLN','vA2I0kIIyHccsA7Q','SfTPnoTqU2uBOC6t8q8cQ','FransHarness4@telefonica.co.uk');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('wqbo1IVvMVCs2OBxq','03.29.12 04:15:00','3gNtJo274oe','Nw1JtBkDo4hcUddyKmrC4C2r6Uqp','6SrWtTGg7WWNDkcHWJ','Trees.Cappello@web.fr');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('HfZeYZvGAyI','07.26.00 01:09:00','8XnfiymsTWyMj5l3sRDgQs6ztCDrot121IbbKmHXtGRk4hihBt05SAPrOgsj5wV5FHQdSD16PU0Q00Lxo','zNsmHBcn','l8jUFhpvz7ZCyQRk6bSkQWNFR',NULL);
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('fK6aiTt','01.01.00 00:12:00','C0TwAXEmWgDxEfTI20P5wSwjan5hpDgCwknruv','QvSzKwpyNQYWRaf4wEFFbOk2x0hZo','V6atsxIju','RichardYoung4@mymail.be');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('nZm7gK3Req','11.29.00 05:40:00','48VrAvrssinqlPgYml85qFOaXwIEGFmG3MJVl82HcoYumEJOUfqAU2STiKqQSCTH','hVn1I1yLYsIc2','j','Pierre.Anderson2@telfort.dk');
 
 
INSERT INTO account (user_id,acc_create_ts,password,first_nm,last_nm,email_addr) VALUES ('hRgbCzDSUxqvyUCyaWL0','05.17.09 00:33:00','pmW6lFhVetjJdTVCoA2ZqAId0YlyMplGm3x3hXkgOs4iBujM2RUzALCiJ4P0qzkEcC4bduEmvnmJa0Ob0NOLhXXFLEauluKZhxuBm08rnkiki3CVU5LZkfmj0Ty1WCaElxr0Vve68QgDHuIujIuTHNHPbkpygkNaP8dP1dB81xHk68w1xB8QwRUf5t4QSkl6q6hxNiTyaEpShMMj2m6zPz35DrXEJiCIEvpBRuvkbgoM7Aaw7Q1jfFMI','vLOL14dJCpqlzFJmwMqH5KWYn0K','ql6UiK3rl5XlfLk','Frans.Anderson1@dolfijn.org');
 



 
INSERT INTO dependency (DEPENDENT_ON) VALUES (55069);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (673063);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (339884);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (252669);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (587839);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (121813);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (357400);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (551314);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (862590);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (665722);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (163576);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (315688);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (182407);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (946487);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (902035);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (408748);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (509561);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (414692);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (720823);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (277710);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (946314);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (81526);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (333395);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (731860);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (922353);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (545274);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (100082);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (184206);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (384031);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (498458);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (353311);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (207817);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (613849);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (167326);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (29815);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (205776);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (252487);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (944567);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (783484);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (114810);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (856054);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (753447);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (228440);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (127838);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (665608);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (913195);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (246719);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (765884);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (936806);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (175261);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (780806);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (897892);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (681627);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (366707);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (6912);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (675945);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (849686);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (631073);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (118448);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (679712);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (908177);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (538087);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (334530);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (758461);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (550658);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (530131);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (534555);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (443076);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (532311);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (193430);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (968477);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (620792);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (986930);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (887513);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (763289);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (248077);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (NULL);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (144248);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (673618);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (828994);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (317233);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (23870);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (313494);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (832286);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (895588);
 
 
INSERT INTO dependency (DEPENDENT_ON) VALUES (282657);
 



 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (1,7422,5483,'04.12.06 00:20:00','10.11.02 04:36:00','11.01.04 07:07:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (2,9120,3633,'10.21.04 05:52:00','06.06.03 03:19:00','02.05.06 08:51:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (3,9221,9763,'07.10.05 05:56:00','01.05.06 00:35:00','12.27.00 04:45:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (4,1747,NULL,'12.14.08 00:41:00',NULL,'12.01.03 10:31:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (5,8167,9662,'03.26.01 07:17:00','01.08.02 08:21:00','02.27.10 04:43:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (6,NULL,3326,'02.05.14 00:10:00','05.27.03 09:53:00','08.28.07 08:19:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (7,5833,25,'11.22.03 05:51:00','05.09.13 02:03:00','05.14.12 04:25:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (8,NULL,5356,'08.27.10 04:58:00','10.30.09 06:38:00','03.15.02 02:39:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (9,6021,3647,'01.16.03 02:21:00',NULL,'04.18.02 08:29:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (10,NULL,8653,'07.11.07 05:05:00',NULL,'02.13.05 03:45:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (11,3166,299,'08.01.13 06:55:00','07.27.09 03:24:00','11.18.10 02:25:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (12,9281,7337,'02.01.10 01:08:00','06.03.06 09:58:00','01.24.14 08:12:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (13,NULL,2885,'10.18.12 05:06:00',NULL,'06.01.04 00:15:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (14,6146,2517,'05.21.12 07:56:00','02.27.00 05:14:00','09.28.08 01:06:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (15,4543,9677,'06.25.12 10:42:00','06.21.13 02:05:00','04.01.04 10:19:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (16,7059,8292,'10.16.08 07:56:00','08.21.04 00:47:00','12.15.13 10:38:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (17,4508,1948,'02.01.14 00:36:00',NULL,'04.05.06 03:38:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (18,1707,1394,'11.06.08 05:17:00','11.23.12 07:01:00','08.22.06 07:34:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (19,NULL,94,'05.20.04 06:50:00','10.25.00 01:01:00','09.23.04 02:11:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (20,516,3010,'02.24.12 09:31:00',NULL,'08.29.07 09:25:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (21,9829,7022,'04.03.12 05:33:00',NULL,'03.09.09 08:24:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (22,9318,3761,'04.23.08 00:30:00','12.08.04 01:03:00','02.15.13 06:46:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (23,4433,8060,'11.06.02 08:22:00',NULL,'09.17.05 04:03:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (24,NULL,6148,'06.22.01 01:17:00','10.24.04 08:43:00','07.18.02 10:44:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (25,9005,2367,'09.01.07 01:30:00','10.06.05 08:17:00','09.07.02 05:15:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (26,NULL,4672,'03.09.05 09:50:00','03.01.03 05:14:00','06.14.12 08:28:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (27,7894,NULL,'05.09.02 10:48:00','09.10.03 09:47:00','08.22.03 01:26:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (28,1173,3318,'09.20.10 07:30:00','11.01.05 09:12:00','02.13.06 02:02:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (29,5625,3262,'09.06.10 01:47:00','03.11.11 02:14:00','07.28.13 01:01:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (30,2530,1468,'09.04.02 01:39:00','03.29.00 04:38:00','09.15.05 09:05:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (31,6289,6181,'06.10.09 04:13:00',NULL,'05.17.07 05:06:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (32,9780,2124,'02.25.00 02:06:00','03.22.02 08:51:00','12.17.13 07:22:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (33,8450,NULL,'01.13.07 03:36:00','06.16.03 04:53:00','11.10.03 08:22:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (34,NULL,6303,'11.29.10 08:47:00','05.18.05 09:54:00','12.15.08 00:20:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (35,4511,380,'06.01.08 04:43:00','09.23.12 10:02:00','11.29.11 00:31:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (36,NULL,NULL,'08.07.06 08:56:00','01.15.14 10:18:00','12.23.13 04:28:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (37,7687,NULL,'05.30.00 04:20:00','01.29.11 09:23:00','03.08.04 00:44:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (38,3486,7426,'03.23.08 00:06:00',NULL,'11.21.13 07:56:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (39,5571,2611,'01.11.06 03:37:00','03.26.03 03:56:00','09.27.10 06:05:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (40,7299,6400,'04.01.12 08:22:00','06.27.04 05:29:00','03.26.03 01:28:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (41,3426,8057,'02.01.00 00:22:00','10.24.08 06:40:00','05.04.02 07:52:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (42,NULL,5595,'01.15.05 04:19:00',NULL,'05.08.07 10:52:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (43,8657,1589,'01.08.11 03:26:00','01.22.12 06:54:00','01.20.08 06:08:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (44,4638,NULL,'04.28.05 01:45:00','06.25.10 10:29:00','01.13.13 02:05:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (45,NULL,6406,'03.08.09 08:05:00','11.14.11 03:43:00','11.10.02 05:22:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (46,8203,4873,'03.25.05 04:54:00','12.31.02 09:31:00','10.15.08 09:56:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (47,3229,9570,'12.08.05 09:42:00',NULL,'10.11.09 02:08:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (48,2297,NULL,'10.14.03 09:42:00','12.08.03 00:25:00','12.16.08 00:22:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (49,8449,8682,'02.06.07 01:15:00','02.17.13 09:11:00','04.22.11 06:52:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (50,705,NULL,'06.12.02 06:39:00',NULL,'05.18.00 07:00:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (51,3438,5473,'04.22.13 02:50:00','09.07.07 06:36:00','01.31.01 01:19:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (52,4572,7678,'02.18.04 07:44:00','08.23.11 09:12:00','07.24.12 09:49:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (53,3498,6318,'04.03.10 06:37:00','01.29.01 07:31:00','04.29.03 06:40:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (54,NULL,7117,'02.28.14 01:34:00','03.14.10 01:14:00','06.20.02 09:09:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (55,5485,7182,'06.20.04 10:18:00','11.02.02 10:03:00','06.22.03 09:46:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (56,1416,NULL,'02.21.13 03:41:00',NULL,'07.18.13 02:21:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (57,7587,2388,'12.23.07 06:37:00','02.11.14 01:52:00','08.20.06 08:05:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (58,1036,8083,'03.13.10 02:03:00','08.01.11 03:27:00','08.21.10 08:05:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (59,8886,3959,'06.08.06 02:17:00',NULL,'11.04.03 04:31:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (60,2527,6447,'12.03.13 10:20:00','10.14.10 10:24:00','02.19.08 04:00:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (61,9797,3170,'10.10.06 04:53:00','08.08.02 04:36:00','04.28.00 07:03:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (62,9579,NULL,'04.19.02 03:58:00','01.28.04 08:14:00','12.10.08 04:41:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (63,5886,2064,'01.19.08 07:42:00',NULL,'07.30.09 04:05:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (64,417,8628,'09.25.11 01:51:00','11.17.13 10:22:00','08.17.11 06:40:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (65,NULL,NULL,'10.28.11 08:48:00','07.22.06 01:18:00','08.27.04 02:19:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (66,716,5536,'06.12.09 04:42:00','08.06.10 08:26:00','08.05.01 03:35:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (67,6944,3270,'09.08.06 02:13:00','04.03.11 08:49:00','04.24.01 07:22:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (68,NULL,2781,'10.19.00 00:51:00','05.16.04 04:52:00','08.22.13 00:48:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (69,2592,1744,'11.21.12 03:25:00','11.14.06 00:56:00','06.16.01 02:21:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (70,4743,NULL,'08.06.12 05:50:00','03.09.12 09:27:00','05.17.12 03:43:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (71,9674,9495,'11.18.05 09:27:00','04.14.08 04:52:00','06.11.01 02:29:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (72,4450,1000,'06.18.12 03:01:00','01.17.10 05:45:00','09.15.09 10:53:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (73,3648,2997,'07.31.02 07:58:00','02.02.06 10:19:00','10.29.04 05:38:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (74,2737,5135,'03.07.11 00:44:00','11.25.05 10:35:00','01.17.09 01:18:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (75,NULL,7309,'03.19.11 05:05:00','05.09.03 10:16:00','03.29.09 06:18:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (76,3200,9952,'01.24.05 01:48:00',NULL,'10.19.06 00:49:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (77,1216,4582,'08.09.08 07:50:00','01.14.03 09:21:00','10.05.05 05:13:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (78,8649,NULL,'06.08.10 05:32:00',NULL,'06.18.13 03:40:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (79,8955,6472,'01.15.00 06:10:00',NULL,'12.20.10 09:10:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (80,NULL,4155,'07.20.12 05:33:00',NULL,'04.23.11 00:15:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (81,3749,4381,'01.24.10 09:42:00','12.09.12 07:37:00','11.08.12 01:46:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (82,7683,9700,'05.30.01 04:46:00','04.13.02 02:46:00','05.25.01 02:45:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (83,2616,2996,'10.05.05 04:55:00','11.18.02 01:11:00','05.19.13 03:10:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (84,6051,4849,'05.31.13 00:02:00',NULL,'03.11.04 01:02:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (85,NULL,6411,'12.31.12 00:19:00','10.28.07 08:51:00','05.11.01 03:11:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (86,1,NULL,'10.04.02 07:05:00','12.08.05 07:27:00','12.07.13 09:33:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (87,NULL,973,'07.09.01 06:46:00','12.18.00 02:58:00','08.27.01 07:05:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (88,NULL,NULL,'04.22.00 01:48:00','06.08.12 00:25:00','08.10.13 05:31:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (89,1736,6706,'05.15.02 08:42:00','01.03.05 03:39:00','02.15.05 04:19:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (90,9181,8195,'02.11.11 08:32:00','10.13.02 04:52:00','06.14.08 09:21:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (91,4519,NULL,'04.21.00 08:51:00','07.26.10 01:17:00','09.15.02 07:11:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (92,6081,2180,'11.16.06 05:23:00','02.19.08 00:02:00','07.20.08 00:01:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (93,2084,7307,'08.19.13 01:05:00','11.10.03 07:30:00','08.06.08 05:58:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (94,3042,3904,'08.22.12 02:11:00','08.19.03 07:17:00','12.30.04 03:22:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (95,7318,1173,'08.08.01 09:02:00','09.20.08 04:39:00','01.17.01 08:58:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (96,5102,2767,'11.13.10 08:10:00',NULL,'07.30.08 06:12:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (97,4402,4836,'09.05.10 09:53:00','03.06.03 05:46:00','12.01.02 09:12:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (98,7328,7562,'07.27.12 02:44:00','11.05.13 02:28:00','09.27.12 00:30:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (99,6537,NULL,'04.22.07 06:07:00','03.31.08 02:51:00','04.22.13 08:31:00');
 
 
INSERT INTO estimation (EST_ID,ACT_HR,PLN_HR,START_DT,ACT_END_DT,EST_END_DT) VALUES (100,NULL,3233,'03.12.06 10:01:00','04.14.04 07:41:00','03.08.02 10:36:00');
 



 
INSERT INTO project (proj_nm,proj_descr) VALUES ('CBXcPPNmw56ATJdAAaV4cVkD8H','UgsDflTPXQXaOF2LBvc1KD8vUJfpaSAJdWq2wiMkidMl6eYKF7xZHPpdvEvZYUwzCtG5RhBVixfiUglzD7UbdiDReRFxUcAZnx8zjnPnfKeHRTnC8CZgn76l0U5S');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('SLNkl','MIRqIbBBdL3RGg8FY0ZsMweVsePv3zSuYlvoRzic407ECZFHXz5E6JMdVAu5yh7yeFQxOB5Zzr');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('dmnUbWqs0H8DRDSqILIzAPrmaMn','cLj21VSFFy84DjL1h5S51fyyzGgoln6AmPHHgODYQcY1d');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'hWmNfowqhGBFwPfIFLBk8XDIP7U06wGoo8AAVLtRqRok0vkxoe3cpJ66ri0QWM56u67ArGYxnOveU65lK4Vvo2xDeeQRpWVTrg1w3177WbGjCjMw0h1Z0fXe04dcTWqySjk7KSbRvQcLhrmoVRoVDZSciwjL4as');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('6K','zqIPsZPAC7WQUpHk0OlAAXKLZVTQXgk7XWIKpkcvJD4bMeReaDch22VheiKWDOzm');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('WA2T7yBlF6mUaSOiOkf','LJhCYe6aNiC2j36Cj3CMdK4AadZAt0nicpoKXqfbM0Tp7VcRzUG1NZtYzUWMdpAkzOUZwqVQU6HpoynaSqvhhqEIudAhRnunK1wsByFDWTPmmm5xUbaFSOuhrfVE17O1SBeYbXvdABXaFc11xYoMX4AqoZtZAfDPeNMxFiuj');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('ug0UarkqaXfspp','J8eUyJ7aEnhJPNZnNycA3IOgeRg3Y20GlZNkCMzM0SISyCwJRNIsdncxkfLaekJ');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('dZ3Fe6DL8PQY3wC5gu8krLfzxbS','rqJdNNGGZtDLylz28kmK2GQvCIclYcN4dMvshE5REQ7oUMIkFsWj74wITXWCdqGCNi0j');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('SJNN6GrsN','F1ADRTfMtRUdXNAe3QftV50IrD3Uez');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'lrnbZm');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'jY1WPJn3Qf4hZ0AYUNeFneYJmzWtIeHDKPyiKP08L0fOgcDhnJAgmoFHl6dF6WzyNbIUdchUdxYwGFqLNMC0EvGzYeMj4SX3V3EDdP38va3i5t3DICT6egE3BW3DWYEvvH5MysXqVw4xKMSlBAUn5IO5etvQcrrQV08wOmQbePErm6ONb5PIhTou83Axs1');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('NuRRIMisJDMGghc7TyhahI6','rz2kRuCCZf8jvLGveLEomJj8N8YOTTOTDHGKfRUmAMXafZhDZdZ04WMoOakwUNjX1spcgFNri4E85xApCXK0iDDCkeSXyG2giCVBI2pIz3g');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('zPOfgImpcsfUX',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'oCLLqT5KJdVoDL3yfYh1vU85MxQcMMzw3cpXoIyJc3L0Km2ZBJockwWVOTKZlXOszM75R2QALqMa5Djw');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('sGlmsRtOFCWyYaJhCCxdzkiQ','kWfhMYNhmrFKC6iiKjj4I');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('u15NVIOI','sjQNAU3A8izXPOn6qh8');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('gdlx6kKzYzgWkfBZ21','Zz018yRkhAZUUKKcRywp');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('qu','yLYLA8EBOXwPyccAalyGsLqDAqwnphjvizpQtwtyuLNo8K8Ep53YCq8YhcmX2lOsSlAn3bpUmLa41o2xhTyrQQHWYpWY03YPQRKvC5pKujv80Ja8deVYuydzA6E3a8AbGHETvnzlRcckIFdM5SkTGZEoWZWtbXGtAK3vkdCpSTSD6SL5Sx0');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'grJ');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'UFMVZmi1yI');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('dXfZSbN','l4bBfycG47XybSjVJzvlm8FKGBhQu2kxD7W4EWEb4l856V5DnXOnIyFhzSGMiD0JWIxwFU7SosWTAYMbmBOBWyDHkWvGtykP5lDZvmPCpEZP0fFcH0');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('bhiUGHFf0FMag5hKrwaeyIcWTKKe',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('enSBttjJhFwmV','UE1eJhIQS0Pi7aSuWEltTgGXI81gOreigUXwz6JKMqn1rFsIDWDc');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'jsugFQJ7RWb');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('lnaUoYOXfAB','pX80V');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('EJH51JIvHnzltOp','R22zcQZuZXc1AEJuxWozfq1MqGBduzzuWTG4myfKxTFI1vZLewA2GDdfRTVcb2RYQC1sUC0t5D2mtBr2zs7zAJATiI5bEPAI1cP3DIZBPY7obtD7t5j8BE');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('acXjoSJVJofI0W86fcIYHMt','AN4jkwQVfSo0ZmXgzYfUIV3XeiRUmUwqJlCsE8bisHhBg6NzxIDs3WEtktudOXjzrG06xM1ju5q11ujd0LpAGzN7UUFKOr8vVhipjhYjIh4D5djS2CNJ20IfeYmKdcrcfHoAS5xu1k');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('kd1LHZkDZIS','M6SMyf385pjCKXZfTdudSeaHwNXcwvDRs3Tkxio7zqnpWAyWgxTIYAqKznF15AuJqep2LzSzWdbpow7hSf7GSlCXHOeTrnUJSjuURdxWj4NfBDgwFuAWiZEaEI3mdcEIpJUAviXey4OBOmD5ubdk1EYEv');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('BlxbtARx6XjB',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('PvDLM8DPjyl0VTQr45zJ','LqotSXMGWaonjzPMHxehvdHv8dwqzu3daZgNQIHbdsDvMvWwURnZDK6mLWElEJjkbxGHxIA6crJBCbwZz778hQ0kGfjr73y5DUiS8YxbBXphPzNr72t84xi0oIOPoGF0egetGir505tf0RxJjWLd5k1lVaVaxdpmUYUts3npe');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('kjAqgVeHDdeLeFmTpes','0OQu6lW0lWxwIZd88pzBpfXXqhRNXGI6DKjd8GZuMgCwUQkwuWBZNcRmUxZOotDAjnj2MdkhgWN1uIUafZ6qB00fs3TLMgqsqkvhHeY1n2Yfjvdrh4xDlrzGl1uJFnF84yfMssz0YeiJyUEe5upfyoLTRCd0boT7');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('pLKYtcpet4GiYh0Ev0Rdm','NADwEQ5XsfIiNOKsSrSgPQDbbDpmfsKjNkmYChm6Jpb0VrGNs3myLkBXcjfbtg2XhRJ70CJ4IQ188hyACKeSNyhw8vLRTkoadA2I2Z11dsdi1xdctKffWCotyGVcsWUZWjTRnNZMjk8QC3');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('bnFEDzWAO','fGcnycz8ybH5KWkQL6eS5HWu4X');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('oEb23vqco7Z1Xp3NaGEgxIjFiOL','FlqtqMBBS5kp6BH7EeTC2XAaIIVwjxibWvwPYOt2DuxLD34jWS20z1gC1xSpHUh7');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('7HEBWJY22X5Laj','FAgamfcT1zz');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('8YhHgROpxjpGYRr8','VdwyK1pDvGJc0BWtmG3xT7UCgIUR65cWaZ8Qk3MxZhZOP2nsUkf3qsOB2VZBHFriUgiebky31jzQtFqqiSRjpPkrzMvqGKC6on6KslkZQOUqS6TwJT1OLRirfQ5dOXUmdKBTPBQtAg0eLJapJAbpgJikJObsfWnc3EMUpi');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('i2iCWLIjBE0AMrxY1QKmP',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('qtduzKIOnOHyZQPJNoY',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('aN77kvlrKroPZu373C',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('AFciX22XvZtJjIOn','T5g1AEwiG7YhA8hZ6mazD5TqWN5VUZ4NXwYGNXhNRadJaP8ZiJbfveNaF7of2p7UH58NoZJEebA8qqBQuiAOjCkJE7RJkL0OQORETgBrN3D0zdKFIBBoFOlFPiBn8ZlSSZSUeXYddYPQ4lKxTMXO6YNHPakM4GivglVBeTjtEW5ucSBYnh6jCWcq3');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('0FarDF6i','ntWZnRFKJthrqJYN1Mm5gmSvp4kDWIjptnGiEjoCjILHeqQqeVl4wGA3KIlxmZoY0hAYhP77kls1hK5l0fA7gfDViXJlRoSNCsCXBq3x1W6FRbC16GNo3T0u2nPRf5SwOdjSSv7PnyQvTcUqJaixRhVDKxadoo2gF1JFSCAwnzyVyZDptzp');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('WdCRWKsKEqKajlbfSRFSlTo4mk01',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('IvfPlSIUvmn0872fjTHtwak3GqA0T','FgRxKRXiZTkhdDtMQtx');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('Xuat35W8iBh6hSxUU','LmuGmcfifblM7fk56fvIhPvJhzVl8aKUZmGTluYjDmBI244ElifEVWy7VFxLJznDRLUTMIDbSMOeRHdKftfO25FhL0Nv3t148OesiwKaeCUqOQbHgRBt5tdkuruzTCuhZrl4vAQ3DC5WPbKTdLgwYWWc0Ckq86uTOks57eqWe1jZF1mzEiTjlROvN');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'Ax2FKxlhWNpdXOlITYBWH7vYpdlCJkowyNRLCstLWutd');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('r0Utps2Rckem1FymcN4A61B','wCXYwKNBqZIV6S0Z3yPeAYVPnf7vzdi4HbbZBQDoGNuwjGdDOI1rNxhgVJRVlZ6DwxgUxEWMVradJkFNkMsKiMeenK2xgFpff1lp2CwwLnzG1od31RylMf077kouYE');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('kxjQngOeumcBIf2hwa1F3T3hIyvg','GLwgUJzSJT1cj8U6F7sLUrMFBnYm50xabvufaZK');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('kvtkFHov6KuCbZTD',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('mpopg','t');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('dUDOsyBp8840LQ77lC3PB8Ik0lMtwJ','qe8ZlYW8Rtuud5fZLiD6IekWziKEzd104byT8sqOkb');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('6qce0eg0RdNMQUcb0ZeNlXNC0RY','knoSp0Vi5SuG6UJs1dQmKATyjPVMYd0KY2PDt6nRyuVQE6hFNF4SOMNN2pwf7RO6hVKlOUNYKTkRT2X5Yeq45NgPUMfPf77CwGZLOgYcMrfVRzRzbHISSgKt6cn');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('YSJXeL0',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('JRRRLEnKrxNdC','LUV2BjFpejCnQWA5r1E5f5pIZIDHvvSLhVDtwQLuVdVsbogJnZIw1Q2z3h5ngpaCNk27BgnNEd4V4zPt7ZcViYHUYJkuLJToW7');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('k4f5','DUuhlaB5QC4Mua4Ru1PWyyGE5AX');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'31NLCwaMW3s5TnEQTzhJhDYUY1eXNYJ74nXAUIiD604KxTGLD65P8xIiA6hYb');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('skCivCOhZ3I17aZfFHjC','Eys88EgIGnmGp6aSFZamlyweixqypZiQZaCj1ELLCFlZLJi7a7IrtOGf30VjFjTEZ5GAr5gPtNLaCdkYbQs7xsijZfhGVycpNXhOPQRry5LHKJGHzZsBsJu8OIVLXmnAgrZxrnDzHJA66CfF0JkLjXLWDPw5BVc');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('m','Jfk0wnVZeR1mLs5bB4AwOLXVgsMMwATEjiInHwqVOsYJElz6FSXlkqrCQ5RA6RAJud34Woy1dH58ngkaopLsrtin1CBwvrfRpUcKYwoZZa6OXlnhjXQC');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('bgoNxePY',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('8zjnIWswdjWIq53PIkYmUTBBSYjB',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('RbJb','Er5ZOQD52nfTptsQjHSeXsrbUqTnVoff4iRpTyG34R0Y');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('lhCWxnQ5aBw','FQNVxJhXaFLpXmECbFDKNhJMbMYVpQsROMrEw1z24IWWPWi');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('gzAHirttjDWj6AGIKGvvCpi','uKUBCUaNaU7roe45CEaWRLNsC7y1GXoPz45qgViYsmR4PMNwd77IphO2VyI3XsNOT2hf1j42DQHZtGqF58qTTvC0xNXXc0JqCkucUuN8epSBjZi2XkFcMXmScDbIvxMgtOg8Pe4lfQqO1msB');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('TXuZju8zHAXfLRyw','4QhZgWfJPuFvHpgaGstZL7AmRgf8hB7L7sKKnXjeikkUaRLGWTmmheJLIoA4B1CUDXytzsXJfUzaID6r1ZCQOlsW3');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('nKqglxftyM585FE','WIr11YIO1N4LSu5RLBBieggUiY2');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('Mvhgw','57qeZrn1HibdvZtNg8eSUZqjIQZhtDeze1kU3LZQo4FO2tZ42lM7ZVI5DogM0M2');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('PEsm5LorH5Eb1LGTU3LG',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('s2qJj3YpV8','OyX4TS0NSiq5yDcWRH3KtXAmX3Xv8AoC6325OtbEsYLmapdiHExAoB6PYXAMjWsgnEMUvW4sQHdnBanh5emHgknKIguwdfh3wp3hwfhLWw16PmLZksY1hmG');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('3PeMoBfaHuMF6YBiX','Uu375wKhtOMGypbLC8k8Tiwhmjkry8pnjiYXQeJpSoWzbftGia5U2N4GR3RyXPc130rmIwCtVHbURaltTD6SYTJQrDREkj0urx0Fzt4LOL3Ad232q4mWBd2ulx7JSABS1ifFyGZw17JXuuNBzphJEjJEW6ugW6TGwv');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('mI','KiBdYxpaAqxEWn3RZYvU');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('xgFBu8pNtjewLyI7p',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('nxqA8xniH4hW07WCA7n57e1I','rdaoklrxAgrbJ7lXEEVhDoAqOGmagJHRHtX8Aq0486Mf4z5lDl6o3cBIhraPaRPeBQIZJ4segCLDcRFVkTxbYT0TbULnKeqpA6');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('lSvtAwLS','2nLnrTfaggo0o74AxK8stpHgO0FcUzyyUkwabDjAxI6upN3QbPHm0HSI2JsXnatOBY8NJHQUnLIFaLZ3zPu02Bb0llxUzCPecofdOfevFE1gaDOWZTTTUgVyG1mc02qsspt6FI1qu6p4BFEPDw1pkvaHLytpfOK0ZUGPCFk7LN4ymaD4z06RBjc');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('wahz','5Vo2n4dybvi4Q2LsiPSk61ZHBEh');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('SUGvO0mU',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('1ZmfwNyz5U2o3mlwayXAa','ZsDRF7Ve3LRHtdWggdLfOWRoXScwqfyXNU6CXUpsaZyxrHAliMttbOlpVEW6trRhcS5ELBCDvx8kwRVJfN33drd7IKT47PUPMHzdhlcI5TW1e7p6Zg3icYH15MEZgt5oXugSNjH0VVH2RVE17sae5mc3Q7hJOpeODzhkJNHamxZS');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('pmp4dqMeqX6CAT7K0H8BlZ05RNX1AK','kVPX0gZRU0qUdxXwqIcdHEuckNlJuc6aIcOem5qH8cPeAMWFXvlpu17HE3rGqpwVkKmgUl0nOeaZfiMYwSmnJcVxIRUg6sluTFW2gmdfAWBSnHwMv2hX4jDAaKXWR5XZVpeAqcXPINefbYxd7yWpJ3zUobk37nAJWQUtDoqKwi3LjucRHfSI');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('EevyaBC7zjc2lrx','KB580rz736ObqlhW25w83tOGytoXmXylWXFv3');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('xw4ImG1zmDrpMU5','iC6zt1riJ4jFXMTBJc0vLmVjGuocDnYOFlvvwyRs7RP41lUyoSx4TCXGdIlSJk16luPnvapBJZq0lPzy3XrBxafelwJkCvkFwlwNglBetaLAFaeqNRkJKdoS0zyUPl1Ju');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('p2eiKocPV',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('zytTci4Qz','6qlFfRuYjMFcXQCwoDWRpZgYcTdJ747aQ2XNbPq54m1OlOJtGVeApjybZ3SzP3Q8b4cp12');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'nrQzhnYuYCZjaM5Xco7wIpinke0DICBnlXrlvjTaTdN477tGFPgr0itZZbrr6aYzHA7KARcs8nFqWxk5O2tvDfQbYRKwVQzei');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('7c',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('Xq3MHtZk','NOWiqqbrZMq');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'dAJmNVEsyjsg6GjSDoghSzF8Dn4jVhZvTnRb8mrmZe5m25k8RlQ7foQmex3UD3XDDDYpInuowHOyxe1LcC7goXUt5xjlgKFihzk3wtShCalnbmCzo0LE8ahWpbWKSUsG7O');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('DPKczyl5W2vTX5wypsyZwyCzrPM','Y0om4KLYIPVsODouROQVWS0mDYsymGbQWUBa2qbKhtQR4fvieQMNQSbJZXXT1vkUJL4QisqNYSMIKmTXgyI5W4SZXIqxsxJRF');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('Uu5qfa2QVyar7Z','OSSP8AXz71IRqBZcUuiTNJYt7WeZXcHL52B7cKsU7XFKMZOTzjKlry6teOfYu4UEry0dgdU4dr3JLu6XEUM317SfhOPEwn7uDCsnFHvjVhj0EP05bHVIZYXLuMS5IXRGdQnvqvoCodk5BqJCdz7pFEIkbpQRKiM');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('Fzrfy1',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'hs7M13zepweiPNBODlbsURWyp0l7zJRPjYf8Dlb6YoUDUd1dOQbE8gJzOsqPVWcFygytG8b4eL0RZSBJdg5QRDeO0gfaGR0DNhsk15r7VTEYjX7p8u0');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('5VMi4bWvAKbG5qFr','GnyzNY73KvV1ASDqLrtQmZaBB28e0ZfNei7NVdfcT4THC5gmk3cZx3jjCMTJWvd3LZPNrvilGkZ5SPREoIvpJxPbd5qvGoLSBFaSTn51vaThYmglbvS5kVmGwJbbOoRd2V47l8OWBcysFsRVDbWNaQXNaJ3w5gkSiL4u');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('IPsLh','WvWeaiwFHdVAPhUbpyTpOiG5xrrJfy3iOpOh1NozlqHkuRysQ8go8vCWi3NA1iPDXhyEhOkqmrVftr0REf0ZkbqDPOyuVgDKtgHzAlwMW1HnbN4imapdlBb7eosToLbccBJrVMxaaFr0qqcZccPsEanhscZedlixlVfnx3GHGa1S8hiZumz6C16RwPTrz8y');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'wIgu5gz4gLRIfjvaffMgW501EB1jWputPko');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('e36YhGzUhFO1hBmK','2MGnqxcRZrMhVdYTegkNc5nkGIMmUeuI485EQ0AAScec5jvRUi4cMhaEHhh8UsKH3U8JarEhswpC');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('PAWpjFbgCaqFk','zvQWhd0j4xipn8TH1b1WREh3SdgoikdOuKXXp5LinlJvQ2qksjZNQFXNtgl');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('tv8FD7KEDdInkkXNJndRw1YA','Mgv1RQqOiRhJBOHhLX3rW8ZcakGzyJSkiH1gmI68vFw1stT3jxD6Hw5iVPTWXLC0s50UOxkWrPAVGBPloNAVMKHYSVt7mMGU7YyZoK3kbd4tFVcDJ8XfQON5qNh2YnRgCMaFRjgEW1gFdhzaKT1HaBMnkquPg8TyzzW1txdYhWqX');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'jx5nWBcFWDa8Kxn5dJlr1I3hYHp6rUWVvy3OFxVJfuUIkgPyBvrM4GKxoRZimFFc645mgNE6WHBHFqLffg1Eoca4HznCuwgaGaTK6Tb4nfpYEcfFVI5cQFbe5XZQK5QNiYwqQZkP7WaTLAFH87QGAZfpch05ilJ0ur3StrPEDe5lXLBFcIEcd6sz2ulxAGG1m');
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES ('ApymPvT63fnJ3RL',NULL);
 
 
INSERT INTO project (proj_nm,proj_descr) VALUES (NULL,'TroIr7HfaT6ptVZFSRBhdYtMTByxzWhNiQgKOWjBkzK01MZFLhpAuSS7SZ4PpPeMHq3PLFA2g8Zyiy4p7WpZU6TxGuNyTT2KY1Rr3HsSRaa35GNmzppCBOJiWkXMgqAEJDB4265JKTgZETMXnwyJKKEp7LJhdSG');
 



 
INSERT INTO project_estimation (proj_id,est_id) VALUES (305110,928081);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (395886,361207);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (877177,943141);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (150072,52950);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (571795,754930);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (698406,221067);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (442060,741968);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (248674,230408);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (691861,571887);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (130001,431437);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (347690,498001);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (963204,449479);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (892372,465446);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (878992,713224);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (95085,198765);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (643391,519359);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (522035,692815);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (799777,180218);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (462182,778867);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (186878,51305);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (252372,687776);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (442130,485578);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (236259,782103);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (349766,11371);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (841393,879046);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (142993,280815);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (508848,836075);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (119662,585646);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (459764,321135);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (180776,987274);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (533170,939293);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (151229,357980);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (579484,137706);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (992152,880123);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (144044,560787);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (264228,800229);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (425054,777435);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (451358,484836);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (740319,552217);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (4066,74978);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (987149,82367);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (211986,286173);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (829791,872481);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (264846,150787);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (598789,168780);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (111284,749671);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (136623,124826);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (974910,229916);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (74014,120544);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (636952,655626);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (271273,906456);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (844889,488565);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (409054,494974);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (456437,745572);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (962910,970642);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (178249,129603);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (45999,641199);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (8733,681276);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (854339,201333);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (744334,747810);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (698974,831013);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (158676,316212);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (859424,400260);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (713921,7604);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (742809,202240);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (913740,279552);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (83004,886552);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (657257,633280);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (164212,514589);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (203338,872647);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (303322,908841);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (604615,711744);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (75439,718018);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (720611,278013);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (16943,869873);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (169335,307742);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (790470,333590);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (826735,80816);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (46177,363619);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (733374,391604);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (463675,646832);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (517709,102854);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (708998,24878);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (695349,79469);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (290990,713599);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (453657,549042);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (551473,191397);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (781089,186025);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (273589,178425);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (50624,466400);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (642675,378468);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (416679,89741);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (544053,905393);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (634871,515530);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (432111,566049);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (164006,910603);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (255045,421485);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (659673,54609);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (169642,298365);
 
 
INSERT INTO project_estimation (proj_id,est_id) VALUES (218808,348);
 



 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('a','U2A7Z7Aff5HDHj7iaoY34jstFvoZ2j',NULL,'GDaley@aol.be');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('6tesf84','NHJGS','1-399-1405','TreesLittle1@yahoo.org');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('7','Y',NULL,'Geoffry.Katsekes@myspace.fr');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('8mK8c5pFiTkj56joySZkDC','aWHEuwOdixpm2mC165oG','305-339-6576','Will.Morgan@telfort.de');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('L','aFqXz3LrAVXdn',NULL,'MichaelBlount1@mobileme.com');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('KIsZlhdREz','aBgXPxNPOUIRIQygDwOYqYz','1-427-135-1468','DCohen@freeweb.us');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('tiE3','AouPE0gj1K','658-476-7565','NickSlocum@lycos.dk');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('xyjH5WtlSSBl3RFoU1uBd1','1yxyF',NULL,'Frank.Young5@excite.fr');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('eHrHL5Zuw0QkRj5FNKb6','sed82Ci5wYq','1-850-096-5971','Basvan het Hof@dolfijn.es');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('dpWNJjXtALP1E57lFjwM','FEmjtT3j2N4gWw3TRjLtxDk','1-377-8574','Johan.Slocum@live.org');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('NezxXaet','ubYeDntWOXcQm5V','157-3793',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('MuHmvzuGeMv','kwO6D0XZ8PTbDHEQ','1-544-669-5926','Bill.Watson@msn.de');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('vjyrIqSKvfVSfHJZIeW7BmmGARxXu','idVehEoBcRUU6H31aUG4','1-878-6612',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('i','tIMnpGCFRMUvdPObB8neyj',NULL,'D.Schubert@mymail.es');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('pVZAr6sKn272l1UXd','uXlzunwA5hPqo5nY','030-462-5085','MilanKoss@msn.it');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('EBva3iDOMB6ha7Q','G0Pmwh6ysljUlJmc','085-312-8299','Lucas.Crocetti4@excite.fr');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('rQzKegfoMdLscmIWTsQmgZyv8','2ZlioprxIFU1g0eTr8s0QtIvNLK','1-285-823-7354','I.Mayberry4@gmail.com');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('sEbo3zzzPv0K2vsmjdbpIYn','owaTuhizazDvX5imf6Gm','1-688-6435','L.Matthew1@mail.dk');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('AiQFzSjPyBmWz','FyN8','354-547-6854','Lucy.Leonarda@hotmail.cc');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('vPDiBgqW7PuTZeXtSPEpecHFDu','fZ7fPW6TargbNFbVxt','1-476-892-0562','TonImhoff1@dolfijn.co.uk');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('5ZWS6GKSFPT6Hy','bGbZvumPouQPV','368-488-6965',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('75PIH1H7fSbA6uZQkrQs0lVNX','s5vN1cOwSCkqLAH6TygS3IK7tjqrai','446-476-9648',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('BkZW0LtBMVlEVAuGhG4v7t','c61NX2sUo8sQwDflP','1-398-511-3879',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('i','fYSHgIJSxToAKtNTEYqa0L3FZh',NULL,'EricPraeger@mobileme.no');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('g17xH4THeNSZMs4nYAaPSN','oKFIIsYIQJT','1-085-2140','Lindsy.Phelps@live.nl');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('pA42','6G8xYFu3CuwpZhicKZ','1-494-1883',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('nUQawRKm7bfF','m80fJeWZkXBw0iLQK5rHuuh2TR21','944-679-8602','OliverBright3@freeweb.it');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('UjZoRboubFDpBqKQ1eqY','6yDZ0e7ETxJ','1-816-463-2202','FredDeWald3@gawab.fr');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('2rdzw','fwW0DqnjyjFqGeoSa13yx','970-259-3544','BasRoyal@live.net');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('MA21c','r2OaSS3xDmWEfKEvhJpXYOc4','365-0281','Peter.Antonucci@excite.net');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('GYQYe','dUTObiWOeU','167-475-7125','GretsjVan Toorenbeek@kpn.us');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('jh','ZfPNjhxkzMaWYZnN8wbYI','1-114-6907','FredDurso3@dolfijn.ca');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('QkHDE4Y','baUyvq5B5GLCj710','608-151-8964','EDelRosso@gawab.us');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('rmZXg8Fd','WWXbZ6bE7atMYKfTFh','226-908-2885',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('BwJbGA0SRaZ8AklxiqHRneM8J1ejhB','JTjB','1-737-0020',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('yBxwEvY','cX','1-015-300-0222','PatrickPraeger4@hotmail.de');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('aifYtB','q4elkG','1-329-7513',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('LNuJsWdHRoOejfffGHYtA','bgUFAxvngPh4Oybvpu2uow2IZFG5Id','025-489-5671','PatrickGuyer@mobileme.dk');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('STdu8E7FG4S','l20tqqhH','1-638-9856','Frans.Comeau@web.net');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('wrcfBGcaP8VMvTqdHFtWBw','8Z2aUK0',NULL,'EmmaNithman4@libero.fr');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('Q','kHvmFcSCGLNmJ8','1-477-694-9222','AliceLeonarda1@aol.cn');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('aA2iN0RH','tlvdrMcUn','1-193-541-7361','G.Comeau2@excite.de');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('B6u','7YXcsySU',NULL,'Brent.Riegel5@kpn.be');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('CbzZoCE','NvtvQjPPuc1oQfnVr','1-493-203-9558','BillPaddock@live.no');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('HZJxZ2Lo07E3OqxLFqsms','ftsIl','360-0658','Sigrid.Alspaugh@mobileme.cn');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('8bVPDyFIEAhXg2v','gCI','1-219-9848','BrentRay@lycos.be');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('I15wC8AwpDuJxt6SUNpjfF6Ao','8ej',NULL,'BiancaBarbee@telfort.be');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('Hk3LufqXxzsA4yp','6kJ2jA1wmceU3bftxdJCgk5Zu','1-051-4079','S.Hancock3@libero.be');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('pBfzaS2LiqIE4xSHWFCCk3a44SMb6G','JgUHAB4urtlhcNfsYIgoKO1nC2Cu','1-276-673-0962','MartThaler1@msn.es');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('RGF','jDksc1beXilLIRDi5uvMlVL2','550-1862','EKoch@dolfijn.nl');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('SJspVTvofTs58NzUVx','OprheHQnT8RtXYLPBbMx74mX','1-815-508-9649','Y.Long@freeweb.fr');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('oluhH2h3zvzFSa7JUHn1rEPK','atQE7vnGU3YGBEJUzvk7UBvoIc','292-144-1858','WilliamCramer2@telefonica.es');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('8YyUGw4XMtI','Nlca6JuspG','1-798-1858','BartByrnes4@gmail.com');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('NqrssK0fg6WY0fDfJJLvGktrY0','zVULpD3Mqun32ttNL8KKSXwYl2yt','563-3180','MartVanderoever3@gawab.com');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('VCCx4bsw1Mv','MzkNP86geMO8hkN2','1-737-375-9458','I.Herrin@hotmail.us');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('pqakhHj1O3PRi','rIsALegFU7BEctwa',NULL,'Mattijs.Cohen@aol.it');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('NOAgkoE3zVhdgNrgcYI','DlJoWyO3OJrUvoWSlu','1-926-1062','TreesZia@hotmail.it');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('72lh5ilgdlLXUI','GXUlJs1Ocg3I55Idv','589-4290','JForsberg@aol.com');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('7qgh2kX42PZh','gakbwAqKmL3ks3WgrM3',NULL,'TSharp@kpn.nl');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('OSiZsSfWgFFUFmFSfcspazw','1pxYE1hhQ','1-423-947-6926','IsoldeBlount@mail.us');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('7faHYqpNN1bBCab8a8bhoUP7Up','yRGMFdB0blrqVS4O7aFh','1-826-240-1025','GFranklin@weboffice.no');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('JZyeIwOEB1cMD','JG0','657-881-6694','William.Mejia4@mymail.dk');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('gdpM','ErPxWhtaT5cMg','486-420-6411','TOlson@mymail.gov');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('BxKVnI','byB1tOZRKcvPuUqpyvPfDP2QBon','278-2899',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('hqc6XDQNfMPgwJPes8YpFR55iA','mDKFfnSLxEYNLY83LRc5Hh','1-035-924-6087',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('WcqMWKz6jnrZkRHEaNalelgr2P','qWqYES3iXcuwalUfc5QSaYko6YEDZ','374-093-1505',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('PHUKvWgFYcrFS01z8zid','ejjJXXcj',NULL,NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('3vW1rkvlhOmACzSZmNfy5phoD','I',NULL,NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('Qx16biPGtRyFDmwJl6eiKYf1p','762qOIUQk2IF3MGaVG7r6xAA0VQw','1-374-452-3486','RHarness3@yahoo.de');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('U7yivSg','2aelS0GZjXIWVL3wYEkaQ','1-492-972-9061','Hank.Slemp@gawab.no');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('m','1oWj0L0x','963-2299','D.Climent@myspace.be');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('AYDVVoRE7BF3syOeP','TSVfYaYdA0OLdSKe8','018-0973','K.Sirabella@web.co.uk');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('ZOXT3emMT2UOYHyv6l','iciRGiqPtYfISY64CNSnj','487-8707','Ronald.Ward@live.no');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('IEGyY02wcSQjvLTUaF0','nc8RGWKRkbyWHKbGTQUF6XYTVJke5I','893-360-6276','WGonzalez3@kpn.com');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('TsgFX2bFVeMmd087Qk6jBuiI','T0GjJXqJ','1-841-6051',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('hrnJhWouFeJb','n2t02WV2AilK7izTV0QDjq','1-519-1274','Dana.Lejarette@telfort.gov');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('Zv8jrYxo5IXk','UlY0BrxayIuMauxN','678-137-9816','Freddy.Bogdanovich1@mymail.no');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('Cvv4aEVn','11Wvq8TdzxMCj',NULL,'BrendKoss2@excite.es');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('DU','cQjVyfXZUO3Kva3FPZAoXbm','1-038-3451','BiancaIonescu1@gawab.org');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('LFS7br7WDKgyu','vAkhuekd4VrMZi4B2mKkm0ahMxc','1-703-0972','J.Jones@dolfijn.com');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('K16SG4Ij65WCnp7XRKCWBpud3RxT','qAy2URVY7pEOkIUw',NULL,NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('XHkgGRNfaQPvec','UuTQclxj4lTzjTWQnz','1-177-3694','Ann.Roger@freeweb.it');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('BF1IQV','KhKu7c68gLtpZ3yFVunz4Rd1uKR','1-048-5335','HOstanik@myspace.nl');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('VUyj86dwY5qrFkemElhgajX5Eh','p6yyMiumPd1CEx8hYkX0Mtj1','129-0203',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('MqKceepiHhLhlyIR','3cNwA115Hs46fSjBhkV8B8TzmkGf','1-851-6653','EmmaBernstein3@hotmail.com');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('r6BbxVWCQvwR3WF2','fRjrkPzcUJJ8BGngn8soIVRJLwb','970-2865',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('ey5Fn','LSu8n6nLyRdYimU',NULL,'BrendNovratni2@dolfijn.dk');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('gF4x8XSrSWoi2FH1ho5pG','C1KbG8','007-408-3766','H.Stockton5@aol.be');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('LYxct','WBfmO78H','1-412-821-3720',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('nwq3qYVbAbzav5wmJ0WOeT2','ImNB','196-5124',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('yigPQxER466','R8xjtP','1-703-3986','BobMenovosa5@gawab.com');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('4zJoAoVWj3F','fWvtJSZMEAjtwFaQMsRg','1-372-6328',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('FcPW','V0kCrXxfIVlCbC4sChTCmgJWtw','1-939-321-8104','RogerBrennan@myspace.es');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('PQ4uGhQEs0','U','1-016-4537','Fons.Trainor4@msn.dk');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('5SkdicsZ3','riQJaH5hLH6XA3AqBvVHo6','412-0591',NULL);
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('3AofHLtDeGsQb0CTnDuajZ','xsKzA','1-020-1287','Rico.Davis@gawab.co.uk');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('qSEpIeedpzC6ztN7Zyf','n','1-865-408-6932','Eric.Pengilly2@gawab.co.uk');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('7gRZSp2ihYSByHd6AGfp1ZZYElbG3','3','635-669-8084','Peter.Morgan@mobileme.net');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('bTAad5sVz5bZAyPMjQByOfyvSCXyEf','rHgfbR','806-137-8871','Y.Little2@mail.us');
 
 
INSERT INTO staff (STAFF_FIRST_NM,STAFF_LAST_NM,STAFF_PHONE,STAFF_EMAIL) VALUES ('B7KG','7ZrfFRuSiF5',NULL,'THeyn@myspace.co.uk');
 



 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (218540,790079);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (267267,210866);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (268183,256506);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (982450,161979);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (199560,291470);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (542773,366704);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (616659,233999);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (988840,505356);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (57537,206758);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (845835,513169);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (494995,306900);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (515299,726718);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (6192,641655);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (890555,148506);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (33081,318010);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (742632,564087);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (905545,745877);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (673568,496115);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (549097,864099);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (683983,229665);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (549028,148696);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (651772,393231);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (992878,512701);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (268816,829757);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (763095,456982);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (232568,742087);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (201773,81410);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (739402,347196);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (319327,815753);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (576591,523594);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (968998,979678);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (359799,186261);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (659044,531220);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (712945,373506);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (924505,613112);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (437339,280102);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (430415,756335);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (966938,721097);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (228332,850272);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (656615,760659);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (838066,238839);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (700316,490331);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (76470,551965);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (725961,191086);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (805189,131805);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (363996,363534);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (19217,163044);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (336437,360674);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (948155,866689);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (863304,607563);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (92040,366703);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (433316,642269);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (363617,88875);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (235707,462485);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (758934,801278);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (800065,912195);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (228127,655721);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (641044,92741);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (668282,839538);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (954834,32681);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (210238,697110);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (664269,100821);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (221212,430487);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (359436,896775);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (695118,738490);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (930676,603440);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (952458,3658);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (940832,35770);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (821658,886427);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (33640,870202);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (723722,435909);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (925118,789128);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (332083,76649);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (774847,524779);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (729527,80726);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (984006,36897);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (234058,384593);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (717034,308577);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (315583,860010);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (693811,494636);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (275299,398454);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (49215,406912);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (609642,418384);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (306935,570837);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (230685,654729);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (764423,337682);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (964859,339981);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (835850,786843);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (1863,136264);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (149942,402535);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (215651,427749);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (449583,759277);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (529360,832804);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (590039,700545);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (746057,45241);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (182701,744957);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (517191,364037);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (681201,704381);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (370598,520916);
 
 
INSERT INTO staff_task (TSK_ID,STAFF_ID) VALUES (956795,748322);
 



 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (969970,'In Progress','nwS3sILo7ketoJWaiGyh',NULL,'SNZgnEv6CLp1iaKeWpliDUlndA3D2wOS7LWTd8Lzqozh8BLRiRN08F0SgfeBHHkhdebkwqhctAomFrgZYuDE');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (132497,'In Progress','VDlzjChU4t8JIDOacYsqTCXvNl','ar4FQAhJa4VvRJEJlBoSQJp7dGGJ3Yhpf1TFLsSNg','cwRw3YEOHRB0VJpnhURlQ2XSsJjyuFpmR4fBefOtny3M4LHET');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (419434,'Finished','yQ86YyYYOiSwfM7FtEalBHMXP','lcSXi3a3A2WW2q','HEGa7yknh0mlnPZmsfnbk1b38TrWz2Lm1PAI3EXWxWdCKIZbx5xW5snTqW8Gtn1AqbespL6DcWXDCLj1BVh3mgPh0MryUniociLEuS7kTHUwViAfPYguDSjNdZ0AhYXmtUSoCt50x2Z5anUlUlSHsiN5tiXB38ScgC5hB');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (281387,'Finished','0Nbgv7nSmNePlXGm051gcN8WCRd',NULL,'g4npfIe4ed1pbi0LpivuydTLZNIZsFBR0JKYZc8eVJQ0V4xWLeBWrMTuhpkt3JkBw46Ek6iNUlU6H63UNdCBdiOwcGSWGHaT5WGP1UYRFNR3ZRxC1');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (721263,'Not Started','K0ulEswxellLVaZlzqc4wSRS3itf','UIUHDWTo4SMAsMNuTufsqZtDFWmBatCZElveBGMTDSs36QhkG','J6hZb6fKNcXA0aNZfW1ENlpm4mkc1zEI8NRE7lfOZ63zDaJ0cYJBjwEaF6cby5G6xbidyQs6T8cTYmWXctQ0UChxnFNDfmgB0USQ8ejdxruGofIdwvir3bJr1dubGwbYExtpTFuB0EWbalWZ5XRWlDvVr6X80bkh57x1wJBS5uCfxXYJUX4Yoivsj3');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (585890,'Finished','Pw71V4API2','UXCEtuoteSzWndgpFPwXwHvJgt1Kncku5gFEoT3Sccb02BpHE5',NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (755313,'In Progress','5D6KCAvF',NULL,'hWzg5AuGJCI2GnajyOimC2ZGRM5EGqGJrN');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (72345,'Not Started','Ahe2tjAAZjPPSJaoh7jL',NULL,NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (599841,'Finished','KDu','IXeFH0bbi6d3AjLm0sVeNRbVULVHLt54jbMH6jlVmYtnaoxk0BeT','OG6MZXnBqYwAFOcW5wbU1vLnMv6XlLIkvGQN2RGbvewv4cTR7iXGQLnTZMlCF6Y35QmBmLfeK43KM5dyUCfrMV5wY5TO4g5k5ahQBGvkV');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (707861,'Finished','bwxXlslzQoLBS6EX','A5IDdZVByCx8KGko8DWsmTNKV','zO6vfxpEavlcw6nuWN7wGcAJa4y2XBE1RYLepa32LVtLEgf10df2CXsjywwC1u8yqEIDAlMIBvERDVUWenp2TJK1TBZ17AuXT43VL7cJR3vbvpBF4');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (370877,'In Progress','HXoCYly1k2FWHVs5IHTyQuoTNR','YRKkqXiX0bbKmgF','vXl46y82IIpTAjp0ROO8IttVNbAgTxgxc6VRIPdGH04a3QaoRIZ5srUakz87ssUABwa');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (766842,'Not Started','wa2Z','U','OeaKw00QWcMDdW0jpds3thKhbWcRYsiyWe0th');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (892485,'Finished','FWuUVuayumFjOY0j0El','f0CaBwfmZDWx4G56PdGDHYjfb','K8Dg2GFadwqzaqGZJwOmh5dF7G1K0kZTH60KvpFdyCpjqWK3EMjLY3GZEcXiuCd6qs6nF8iNWOJXd5tBqmZ67MdGYdaMWODJSvzCNtSq7fMh2YZ1sDvQoXLiDew5pTiA3uNUx8MKWeV5rxWqTl8Z1jl0cwhjcOUu42VG76L5LFFMWKPGwu');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (900975,'Finished','HdDzVGWq2x',NULL,'8bBBnLZyRJKyjVbAMSr22dkl');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (84505,'Finished','ZChueFfkrdtTVx8jtx0VjeH1Rtc',NULL,'GAIZxdNW6oBFwuAawnckNtEoS5DD3mR3LPN312YYDQ0RFJJ5MdMv');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (236696,'In Progress','hvZdDGQtGCykI','tWUSAD',NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (539390,'Finished','hAYTthl4uiGbWyha','XK6llkhnujf6PZ','Ol1FudkfpbiY78k3fotO6YSMrKccZQ3rguJ0CUDYQzU2OD61XhCIDyLcCUIs7lSy87yPiMo');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (823168,'Finished','PTZ','KGdpRMn7DkW5emrVLnDotNYrhANoGSfCBkMVp7k6ZpWJIDviqaYQsRv2k','oNJ7KmsHB6ltSrFJ5nIN7MaVyxPHQKuURTMaVPe8V0eYyjHY3mI8Y6vlLYRdLFdXigbyNsGL2vfNBQCTXEzbK34PRlEuyIovwL57b6qIXDNGR3imLR7Wgry3w0HrypiRpHDqVWpCIxHotcUfeRrFPDzgY5piASyQ');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (494726,'Finished','xoqcY5XINBBEu5SWl5FogDBM0K','ZrvYrl08YiLeXaDwQJqWXc8hhAnIjBrHo','Vg4wPgNJHm5E5VP7KlIxTviaqVU3kO4Xc0bcCMjG1KixS71Bxoyf1cWoBvCkBoz3s2MUbfsf6ewOt536XRg7EHl6RxZ4vfyAKggtx6MUtgsV53830EtVPU7MvTM3HzcuLXhzKlqzxAQeOhEg1pQHOCgUCiBDidaBmkvWZh73KM1P0PJPmS1Wqwbm06PNJNHocP');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (777028,'In Progress','YUftdMymHeHUNCVOUgmJomIy','DUvRpcWwKpk5YRO2cDXjatzurfzBaOej0kxhdtpkQSfua2mGEYlg4Rr0QkIU','IFYvtAyLQFw8I');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (435811,'Finished','HZqvz','3pNdSbSzsSx','fBijC7JJlv8W5A8BS54AJ3DNBvhidTsYh4QLbHgr3AbIeGOV5k64YTUQhz4ZWc5wKCqxaFwlleE06b3Hez3myEzMAcxOXuACq6SmZk7T04dR5jlhIXgXFj8cdY0JHwfRIV1RmYDFbZMumBuFutfZtMto1sp4qx6fGmjpsVySof7y8TZnjT8zwSLkNqhH');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (706674,'Not Started','T','rsCywd2bUmY2ZWAyROCPHZVMRw6jXsMlxTS1KeCRZLq','uIPWLbddn41YFpRRUcSroNi6KWtgkK3fuOIYaOTd6MYx32jHfvM7lgvdDq71wtHiYwkymL7yyPEhC562jw2JlcSQo7g3ELms0j1WywG5zGG62z2KpcYSDQmdWxd3NYJcqSpGqkux');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (45898,'Not Started','bTdEMGno82','HJORX5TpOfjLDyevEAg60Yqwreoe3M4bO1U5Hk4W2dE8inIeu',NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (12637,'Not Started','R','d2Rfhvlds2AKf6hdE6crGaLdPMLnNP7LsfzQCYS2mYPdhLoyY7qMJXgRNSs','G6JwmRgwQPIKQKt88QVztYqmFQ7cxAoMpRcVjZ3bEGNidLh7VdwjR181EvxdVGsSd8iG40Utrw0hkC5eBZRCNtq7qCLrDYHaItR17Y6oBYlleTA');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (384826,'In Progress','3nuqqnaoBpbX7uO','KccZEWKceJ57UborLKIKJeDCkTQHxkT7SQ7lZ0MJNvDwxTOGWWUGgCtx0','Honyoq34');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (724398,'In Progress','3','iIe56NYxTZtsXtKM8UiusC4R5K4tdPFNNiU','hmdm2qSQ2SXJxniFs4FeVOHAddSkhk6wka8sGhzQYlXbjsEzaHdyPtzH18FfhbczDAHoKcqUAIU7HQHEXX5mWFMevlps4iUzsIceSGaSUDvfxxH6dVLJHf2ba25H');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (499590,'Not Started','Ee0p84gpK','iBmbJz6bY8PI8PEymeHp0','nlIi6ueqqflFkkHGpkBcuEDpJOUDQSstyoSHWe2BQJiurz0aXa7spWHVt3z4lbMWVwR7yZZw8iFn6qkIMxXdK5wKrSnDnlNUWQ1be');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (875058,'Not Started','YJtOU3eeywBRPZt3q','hHBVE830df3q8noIrP2NisPotjTbrBTiXkJwUcr4Jzpe','VrMpoqEMma5pHHA1NkPJyWhYP4yXLxRkOIlPaP4CqLejIVAiNBIAnDvEkiUBArhD5XjR0dPZ3qjTjL35Ts87nVVa8aanOYv77mrJvoJRV');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (621218,'In Progress','CSqzWVKydCFGD',NULL,NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (308505,'Not Started','4kly','fzCXvUEENJoK043mfrj6g','e8OXqpgYMhlRbQo7ZrnftTJjCdBsi2CG1sRnpzdrMSjKi1');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (176783,'Finished','2j03J',NULL,'gXpsXUl01XefahohBuIBFNbWA8nfcvE4K');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (351234,'Not Started','yhwVwQD','TzjGhjkXDI8jm0I7q5AbDocs3HkcDVFxqAczMbvv','wBT73D1BrzjFGR3eDWF1SkHRfjGA6DMSY7cs16Prv1FsjQq17L43DdzM0luV3NlUsxfSTsSt4BJRzSb1pQeDVcSuUIdyilw5PzYobivJcprT6FPJMDHEKPstLRGCTRRf6iCjDppfIl7nchO5QfLAElTwh3Bb7');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (869686,'In Progress','xNFjMgiQJ4cUHgFpy4a0JU','p3ASTrSKUz7tp2cUdtLRpWO1XkoBINZlL6FbwHgQil','gjBsVikq8MWOiJ4HGctWPNsBTTUymx3RfezYnZNtmQVDGc4EfM8gISof5z5BUV0TBRFtj6M0G');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (361886,'In Progress','SlJB3SnfLZ8oc',NULL,'x03asWn22unXqC0z6n5t4IpmY86kLD0VWPA6rvuWw1hzK6OOEcYxqu6gUQNSiohojVPeGhsJJhCxygGbHHbvvcQDKRrgAJEF6dFkZH57dOqBQwD71KGFX3e5d2ZYsT4hEzLkOBIpyRS');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (928350,'Not Started','zEiFSxW7s7EKS78MQBWE5l1nu','81tvf75gEFx','a8dbeciuaobMEx7XOVPbZMDMfENwldnliLvAeSGJLwTmJeGCBdSxBejQyeh7hhZ');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (884928,'Not Started','fmj3XpepVwi','5Av4ClGFBqPSBxRSO',NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (500324,'Not Started','wOIrYg8','BFlOnbry3aMZqN0TIMQ8fd','adu12DVhZiTh0oZGfkTUsYg01BpntpwRR2ehJqZJoOLyZD');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (842770,'Not Started','bB53i','Oc8qwvm8WBHfsalLfcVvUTSmA5455NCkn2CzYQSS','6F05EA0nrxiLFNTnw4qOch3x3LWpFM');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (224480,'Not Started','2o18DHuWr1Y4WijbDCyphktvIa','N7eQDWvUl8mYIFcHw1wvf0MQrWyK5Wk7cktN7uTYjBXxGH6U1bsnf','cFqVyqOG6BiUjnQpfk0');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (106776,'In Progress','JcbqR','Og0BylafJdHplFHtVH8ChI4PC3NTrdMLAU3ADzKn1UYgTjNPnemufqfyq42W','Wl8aClSBmRjpOsXPlk2JS7neTUjNboAGFm1YBvPdV6UoUxtcmJzZY6ufX45avNOTr5L5eeaS1NdqbxeAUWijNRBZONg5aebuhZWKcns2dJHKza5YqfijeBiI7nhAnK1O1NzyzvUO0CjHMiHRfCULbqBlIxwq4');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (30140,'In Progress','Of7','Hl1nNdVJ0ViP67P18Zz','nI2IWs6yRmT2JX4aUv2lRfEKQJjW7FwafwHabRZDkSCmy2eZjdLCONzwx2u8HrGniJ6rXMPpg4VR7P1rjUL2TiA8Q8J8a73KJhHCPxaqIbqi64yalwZPmULX2JuF2O2Jb1waIghFM4AfMFBZqNNorHfOlKawWHkOUaEQ88USoRORIdKq6IzpBbYZAJR7P2kyngK');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (90094,'Finished','CTB5AEuV8','gMIJGpGofmfaEOSuOC7JwL7HugYZgvWov','bXFBF0ykfcctGo3hNhpN2ZKNVow743C3dyYLjumY2gc78mFWuj22rStmKXK4ejLcyzxrRQeyYRNn2gXbeIKtubuporJnQzBdFhFTgfnrRaUqr7zdBVWvnKvJMZ');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (714615,'Not Started','c','u','NV0HfnyL');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (60977,'Not Started','Fnf35MJpsOKa',NULL,'inKxDi31GMjqKdcbXxVJ6eHujGtCQI6B2PT0CTJU2DJofklnZfYzjDtpOFngzWbflg5NwVshXTBVTC0cYQeMzPcCRXUmzDFkRb4wfGY2EZVoaqSbGvaSMB3jm');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (407245,'Not Started','SmzxqkF3QXBJocDQTMGUgFeF','sxLKk4iHAA4EGU','clNiyoRFZLXfyAtCLeLDwPQCdfKZMFovRXSSMCMloVsgyLgba1JBBG0SRslpvOXjPEWovy8dJQ5as8JefKBLCsbPcmtrCxGdpjlV428j1g1KC4sKDVjA0zZDjJ3e4I22XcenFdJ3KJz0GCFbhVan1czplKt');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (943634,'Finished','XurlIARiSuCdeM5b',NULL,NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (39108,'Finished','0mXjourz3EaKAZuPXg','kjwks8go08eSU4uvr2a0xdeWpDp5wReSW5lJFSEeKdIoGHpa0Wmc1vx0A','lzH8htouWj0NSKMEpzCL2ype2WW3qLDQxztTaaXvybp');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (760501,'Finished','onYko1WL6sthkgdvKcFWXcQhl5JUf','TWxyaULRzm11ZqW6b74B5GOLbNYLOip2RoGFkIAz2AeCDyz4','EcXUfUu8ZpPhFF8Ko5XO2qedRL3cfe83KZD4P6Rwuc5xCBsK6HE0dkNY2tB4fncdXnyje0uL8dzmixfCFYwEgA0v1F2jwzS2iKbCoCyRK8O16nhFaeMlMyfa2L2a3');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (280306,'Finished','GqOUU6whQE1nscE',NULL,'uywSI5ct2X2wDDJOmnrcrOd0HrcXt5QvZv3J7gRMdEIWj32DUuGSNIqNGaSnjfqpWUCFafWJbypHSykngsWiY1HTVEVgk3iAJVrvlFkKlJPrF7cqSwD3V06ml4vQboFrKakOrV5WrZctnR5OINSZ0zRDH4QvBr21TIsPF');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (575151,'Not Started','wqGR1OkuGA3umJXSHuKD06YlBAOR','2I0Ulfyj8FcdaaJ8fkcRAqBaAAd','tGEThWXLniZyoCcsVQCow6niR7uA55G1CygPn8Qevea8Y1U4I3hZJtT5hHjbWysdBz8TB3S6G20TAxtWL0otIT');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (769115,'In Progress','hgagTEXruRUL4J1rBpCgS',NULL,'AZovcYlntDDzLlotCy027QVW2YQs4N2847Vz6nvsRfZLpv8poZIWx0vekQmajMGp');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (172076,'Not Started','r6bVr2C7b3pozT6UrRv2puUy','272pNZJgXWdJfts08OfKBGXsH','YEf50WO7gihC4pBezTkwG8ckpqGiTBsbK8433Bn5jmJlWUrsaGaHZaXAHXauJpXg16XcS');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (133620,'In Progress','GTnXRa6WKBJ4kks7H4Hpcb1tdhDLC','6kZAe8G5','pjRhqi3t1AakIeg520Y8xSIOycUa7yAC8S8cXjSjFfRS8bxl3oySDnqWrGwYvyihF2ur0m8dZL2HbHiOEPCXK');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (168343,'In Progress','ZQNXmztbOF','nYHccdGiLvP7CF4k0GvhMnD3tXhHhVctxF8FpD','nT2NohZ1sCnSAhFgOeJJlGTaQr5SENT6wXQQ6SR3SAAWMYTkRmG8b7hEluhfaIc4SUNyGQjO3kVhqFh1ZMOihNqjclc8JWtQTXNoCLfBHsTet8RtONrJKKyGMlb7yrdQzyQ465mczX6vAZadYA8zGYBR02aH6CJoeV0BM31');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (638117,'Not Started','ijXeZ2T7mSuTnxzqhdR','e7ZTsh0O4yIAxh1u8KQPdtxtA6L1iWK42XY6Q8bmfamZFnoDDLy5ZLy7nxj7','d1Kvke6qTllugSVyFyfnJo2jsdF06d8O');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (402273,'In Progress','y1ZdlAeHQf63ZeCQ6Gtv8RNw','4GaazDYXlA6QWJIFdSW3','4wCMjd06r8pdwjZuDeiSidhbHqUrVJtHoEUw');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (544300,'Finished','FGLHXBvw','RNJeRoPM2C38XEbNkVGcX6rkW68X8KRjWgcedX35q','VxDwRWhTkqB4QfiyGP2xc8byRKKLGjqrIIuA5OVkwTFZThyX4ErKpCRn1ZUpUGfjfQ0cn');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (876583,'In Progress','cngCG0bfYMpXli70XQZy2bNJj','BchP0ykxt5Ukd7MP1H','8ZkVd6JsPNKcVDgDhaiAbd1V6QEfXI21vIfu3LtnJYAlxb7jVOhJzuHOjAOvzEpaO7UwnrrgkSp8ZyjmxvQaaaM7bL6VCxDSd0');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (905923,'Finished','Pnap3NDDAOaLLBSeKvii','LAbBF0om4nM6bSN83','6');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (822887,'Finished','1TC2RBC5iNYs15d0InyiZVRz2q','a1PyIjwLRRdR3fUAAxMuoRqA16t6HT8BIwMVpcpqMvL38R40Q','rElahFdj0nE6uodYWbtxbavfbAGfRW0K6o4v2RTmZ6bzsITOPzXEcdreG0ffvvKzofbpp6Om3sghByg4NQHhsNXytCi');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (990114,'Finished','i6qiJMTCVFdBmfuH','0AwowtEXYjLM676vtGVTgCzetbN3T2zERt','Mu28Ru3ntljk1wIqE54qOQXzX5lSUYGNnfEfe85YaBvEtNM6amoThx8H8Gwe65pvz2j');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (389793,'Finished','AkCmJGveWZyWp8z','YAOBXXBRErJp7wtrpZH6JAeiT0E4WUSZAcCsBe4Sn1cD5E',NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (999281,'Finished','VezSAA',NULL,'rc');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (219755,'Not Started','6z',NULL,'5YRf1L3NUBY7HDwbb1YvTC1Llux33N1aLp8L705Spxsr8FdK4QR');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (604596,'Finished','QuhyOw1ojFK07T51xM','qWj6rpvayrRmmRa2hihJQVzqg2ctWOB1WM8vlO2WNJUv','HoccWN2LqvTqS2lcSSEh8hMNC7djELfywzheaTQPziEK72DhPFb4bFCNv0AkHMq68MNMTc8T5VBDTB31IUtcDjnTtAQqn');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (287941,'Not Started','6qcFC','GUvidyRhc5CVcYQfZmuwRJKtz36SSKs7h4p7OE2UjZL','su7Y7DGTW5IPvCBdvDcR710GadjVIJZRr1OXn1OFv4kOEQAytuAUSHgfAHXOTCBT3wuEW26g8CGW1XygYmHG3rOG5L6CxrO10Q5S3i6bKJL41T22LtCu42ahh4TybWIJxSOdJQG6Luhazk8Yriko1Tm7b5XLTVCcyXLhXepOtTH3FF13axXq8IISeFBnsVKT');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (214522,'Finished','BaPnDPIfc07','rt8',NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (638458,'Not Started','GLqQxErhwiVA4rtbk5wKjUPsj',NULL,'YfGnWBoyl7yZyIgXDD3qRH3L1NFNuM41CgeQqWl7I3jqaPKmro3i3ohP8TkJbb7uphRqsG360r1z6SSlj8gOqRkg01QIs8Tjq5DpOkTSICtnnv5cnATueKvbzN8I1zypKqY2Y7Zgnq4nC2vLIRDQ6DqnH0Hvtz5XFkUaofENXgn6IAaC2jwjU4MbC8pyFl6l');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (225549,'In Progress','1zxFtEAzaTskrPP','krGo727lX2DsM',NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (634336,'Finished','Ebv1ZnUGHzcCf50TxnpuZU7','yq6','6BA3B13lrxEWPJqpZg3yFPcpAUroSqfr3JYSfM6TpyhO5YN6czZ7TltttNYf8WzJQb0wtHhQZZwoBRHGilDbzG0vC2vvvCusdI');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (87505,'Finished','NBcanaxLNF8EOsVWAg',NULL,'1zsR5GMKRVLdaRdnc4TB0wJd000Ok4PSFQrthG4ya3ekT1imAz');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (86858,'Finished','hpi5zlYKNHqAGBtU',NULL,'yg0qRYSlfAHL8It5Uus4ZQqK7HTencEv8wf1WgNf3QGkAaFyOhDVhhshvLxUTtMPTS03hBnSFdSDVBtLB6EDDZlQHLXuPbRHeIsPcMvpZ1xuoEQB0IdQ0g3cohQcRVZKMWx5X2jV0rNrfSBr');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (116490,'In Progress','CY7','zEs2up2IwooIicrX7ej','rf4MQuJXe85uftxnCdVEUiWAIpInLt2TeDGuyNXzWBuL8cxWl0B5JOf6JQ3XFMIlp7jBcSrRuB5L2RYbVwL70v7IMgMw8bfymoYJkYsoVCN7HuOQJVRqvdlkqcFRAKx0s56zwkjZa7WJZyp0MfKgLmxG');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (46398,'Finished','Z4evJka1t4v5xMiZboY8rWx0KI',NULL,'LMlXtCLX1Oxpm3cIgb25USVWayozD2AkJrrVBU4kTBsDuVpIJvvIg2lA8mTC2vFnTgERYpQAoPevKOUiRp2JfqfylaJSvFr5PmoLfFXyiQgrpEsDKjEhy0cA3adskAUlhu6VAhmfa53fnYz8mHcbtRE28flK6V');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (299122,'In Progress','hrj5n6IWS6gFxHLTBrAtdx','eqs1Tt','h0tgK3JQ3ekazE2ZObKPTVkgliEG');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (696488,'Not Started','W8wWerMbrfSbQIRa1hn2CeFkKG','trs6PXR7SQcbS','cqV7BEJmDRZL3kJP7q6PTkzEUNowOCzG1AILS8uqLuJ4ku5ceTTtxg3QcaOR1FKMQy7t8VdrxZsyGH4cAXE828duqNnclHk1bE8B4oiF3pLyc4rfDyxpfqlTvPRj7Zg702aj5sEsjFw0KoXc66z32DB2F112tyJsMDNzd7');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (293801,'In Progress','j8lgen2d6kottZVn','3BxZzpi4znnu8iGLcWJjX100aYRAwRqMqOIm1m4dpNz1x1uI68P','jUx4IMlDt4U2KiJfuZefcnwN1U8yUPL8R8LByyg6LUVlZ2YnYQOQQjbpIYZK05HqYQLZA8jPlEJ5hrVlX7OgrnlxJhXMMxFJioCpagHb5qYP0svYVRPU0sOPbAaRnXHB');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (945481,'In Progress','qnngRstLqklemmhBNq1vnerjGOHNM','uXI6ij0gw7xXOadHat','mAQZDnb3rtCtZmnhqmiHkl2xFHAllC5PNsSW6VrFlOsXuWzIqBThPB3s5D1MY48OsTqOf3NYEuYvu2h7GHXWglnMtWiyMt0WItvpUBqRvkIrvhZI8EubLGYjAchrefG7bXK3j');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (616218,'Not Started','BW0ygS3dR28NZZQXezqBY6qZGHRa6','JUH14XYmLr4fssmmt2',NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (977925,'In Progress','xphCsc3vWE1h','oGeI0tM4TsOBlIaO5P524O4mLQCurAJXQbVopvpOWwie4nN8f','AqcCq3zP6adRAFy0AugD6vfqA1CyzaSXfK150cnrVIAEeBS15ubxsfRpum8CWAGLxtcBqOgnY4zUHeU8ZvwPLDZYadgWtEnmwyEyCZABeQBm0StMayC5xNyyPxZWX1pqqOlX3KQImPYPV5dS4lXhiJ1NugD01r8sUjErv45MZgCgUPA');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (3475,'In Progress','TGYVSXGXqISbHuRN6QUET6sK5n4hS',NULL,'wYjje3gp4a8bJUhZhJruHaeJjMHCz3lGZWR5tk0wny2JsF1WlN6fhXSgwtziRnvyAnOjM6FbvR8prd4gEpOBgrcNxnaQPnuO5YhxL8MHZkBGMRIkPdUOVbKkn1m6BaLYPhD1fEJGbaGx0gUK6NNXzrl1hxtuwTwsVlyju');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (478439,'In Progress','oSZvyXpWxyVvQEXf','7nNJcXjFvYlo62ZMeisMz','vr635NvOlCURIFkfYYk6PzJ5NbiONUlkgPXX3lJ5l7xwnQLgm30W5jlnxmqzIBVSDHDdXreeg1CyyC5QijsxnREZ2DIgxVnQH7yS2tPJCD5i7vSlFDMcuLzOVzHBtKPXVnkDXn3Kzftd5En0kveRjBnbrFWhocFrFj8tVoq1rQPov1BYDs');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (653243,'Finished','GD','PyWQrCgfsF4RTg1547mawgsTyp4Vhx7B1','bCyFJtz');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (452427,'Not Started','vnJi3kX17f8QKsSGsPddEl2',NULL,'IfLeKhUtBzfSyqfbW4tQVez00');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (975755,'Not Started','m7i5Iddc','jWTFMrAIw5YIHFDPdiFRjG4fRNJ','sRMUtBe13hfbSyDAwnSJSdMd21rx7hK7A2qSnYhYsUzoUl1Y4bTyO68stkld8CtdVtDh3o3aFELwzAgV64JwitHmrFbO6r5lhPWU5wQxHU1KwHtb3xZObTTdc7kLWsINAqk61frFWVNJsE85X6ji');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (443110,'Finished','esNP4QRWqH6rn7O24XCanXdqKL',NULL,'l2eYYhmhvOIFUtLpTJNyaOypsbmSdvYt5Pyn7BUZoltfQ6c0D6Sd4KvolLMsV31jk84A3AdkuBO0NktAOTNT5zzEEkhSlf4af4huxdxGtT1zvLu');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (788294,'In Progress','0z2q2yE','LZLGpO3HoeCvIlrh836ZkuN3pu1O2TnU8z1d8igI7W3vTRbd3IGclVJrF','QFll6YEiG2A8uuLC48BHPXYPbRmrsPklp87pYrV4lvL8buLwhv2QAMlQvB0280EH5RijC8iCQmiMgKw0u0VxZpP63Jq28Ix3SIBhHcEdWvn4nB050Sem2jf4');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (677319,'Finished','AA0VJOYYqYBtJN6ucbmfY','S4dQliWHJh6ybhCAdGNHvBulLqIJCjzN4vaUiz',NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (530051,'Finished','iXbzC3kFO38t44ZAt51RSw2ODya','QTk4ECoHQSA5uCt8ZOT7PD271','Zhi8UXSee8gTfrTEORXbteI5yfVCFqYF8M0oEgJQ8diFGPKEl4dSrYq0uO05E0dWslTDvqjAyaOn0FEtn5Uc0gf8TRqFBNABRKxzTPNvYtlt');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (248720,'Finished','qmJmhYHnMS8iX','M0xV1ui','vhf0R0PXkf8J5iJLDPsNAP5I6I3B2FfH8uum7jgqaefQyMIxnnnbqHjZChttAIkLbZk1mFwdsnY1v51l50eVcJt6f25ZpxpjRSIMsXtNoaOYEXKGVDHCU2poRjVpTGxA6eXAp4bMyOL8yHEmkpqK5pfL8EINSfG3jp6pZr');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (877437,'In Progress','yqs7d7RTZ1Z','0OR5VRRXmvD2kh1Sx8PSeaM3mCkTkFPdP73WLwyagiwtth7HWkPlifEm','hbc6dDXZIudSQvadsjXzq3CgTGpNP');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (456081,'Finished','Csc1VcFy1zK','vFHF65hWRBrKOJFqMxgwRHxxoQHHNbvYhR','ncIhf2b3o6PUQmm2Z26zzpHqZ8Mcd1SxJNR5Rhc71VK7sxAtfHtXNZFpW50oWE4mXm5UgtTiDHxppSb772JairFJHlS6zdgTvhOIqx0BUL55WdcM7EPPlVoEYXm5gTv4yFKe372ZrK');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (224724,'Not Started','Q8F4IoO','yAxGNsFotBxqbPSNY3qwyXBwBuQvUsQ43m1','Mihwqc3cfnIiPUZGOYyfZ2zPeQfmPpkHrkn2sdtePuXUhyYdTXuANU5MdcZ58P1gq2OjLVvAZp4wLEJjYrqknn3PzsHhBMGD0JeLVNX2vIQxwChII8eIgn');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (52737,'Finished','QuUE7pmBPPCc1nW','UGTEC6Uf2F5hl4mg6WGxIbuRl1tzOI8fbDJxYDWEDXMRCIdkyoc','R5WJWQcHoMmwxEWb0lPJrqRJGOMhpCM53POH1Gwk1VLnx5h1dtm5AxQWeHCtUmxRqkeUECsyoeezSEYdbB7AWWbUijTtZeVrnzu5TYU48zNYFLzozYllDZsFyOeFLHdwN8i6');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (205052,'In Progress','CdMpPzPyaphYrtvYIN','uMA2nlSTtCVLXhvSwqhIcfuNkKj1d2KQF6bI0qRKocHyozaQfYoXWtoYXn',NULL);
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (644645,'Finished','SscxMuKc7bvq3Jzjq','u7aNWQ6J5n6g0jOdLt422mimVtbN','N3YKERkoPFoxNamTEecnD8EsGzKUVv4OJS2PKuZv3S');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (677247,'Finished','eG','FBRagtHNEKmWZ1mTI2ul','hI4hMcWHQhDhs2E2kTGHAD4kAcUIr58p7pcTJp');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (214861,'Not Started','0OsFvfcQFi','YwIE2lQQGVmHTw8XCg1ax0GlAFrIkQ6jrkX2nRUO0I4Ab','tcACxRMoNNTNyPONcttLkJPhqdp03XFBE0TMKHKTaJhHYJ1B6s55I');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (179569,'Not Started','PLyAMAMrTyjHLMI',NULL,'5Nl3oAV0IDyNrDnVRHF6ZQUGQA');
 
 
INSERT INTO task (PROJ_ID,STATUS,TASK_NM,WEB_ADDR,TSK_DESCR) VALUES (305208,'In Progress','MmnjK5ARCcv','Mf3mBto3I7EhJePS2Br4IyD57aR60NzXkRFoQOEhM2','MTTWWbvu5o7c2peFcsUivxfEsDY3BqJnFiyYWT6I0C58hoRxAfIMOyTPd3qgZHcfY0m62qn20SNtSCUEoUXS3Agy4mkM7bunSRGOkkugZUYrONknlUF01zerwEzYBFqt1Po3DvQuACPOGigRpR1ZUkE7EKLhStRleOcsT');
 



 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (793609,1);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (593818,2);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (494828,3);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (727487,4);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (917726,5);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (198235,6);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (470236,7);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (542036,8);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (532517,9);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (254874,10);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (29159,11);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (526802,12);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (464715,13);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (245792,14);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (73818,15);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (402604,16);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (117000,17);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (927308,18);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (850416,19);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (473455,20);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (124432,21);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (799674,22);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (234967,23);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (743203,24);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (375141,25);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (398028,26);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (125567,27);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (564393,28);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (692154,29);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (889009,30);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (362989,31);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (928732,32);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (723222,33);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (707421,34);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (851473,35);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (758536,36);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (835536,37);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (217301,38);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (801580,39);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (808522,40);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (62203,41);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (631778,42);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (267002,43);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (37328,44);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (397343,45);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (676103,46);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (397181,47);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (558139,48);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (986709,49);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (728210,50);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (77634,51);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (527782,52);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (10681,53);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (421192,54);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (879840,55);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (583679,56);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (306516,57);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (942073,58);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (492574,59);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (688025,60);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (26739,61);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (511234,62);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (56567,63);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (488564,64);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (880531,65);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (776890,66);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (74356,67);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (555348,68);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (755014,69);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (108964,70);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (817202,71);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (102840,72);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (763279,73);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (26772,74);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (400960,75);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (56751,76);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (16056,77);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (244851,78);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (952765,79);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (574973,80);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (663888,81);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (71341,82);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (540415,83);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (381990,84);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (6692,85);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (143273,86);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (786321,87);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (526146,88);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (717572,89);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (733151,90);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (337910,91);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (419126,92);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (477768,93);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (111191,94);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (616338,95);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (267056,96);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (569614,97);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (697609,98);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (515407,99);
 
 
INSERT INTO task_dependency (DEPENDENCY_ID,TSK_ID) VALUES (252567,100);
 



 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (224378,989314);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (972546,77213);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (771856,495398);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (583744,723621);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (888604,165780);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (684295,546733);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (491676,47400);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (567249,53537);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (74744,152320);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (761419,980637);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (533478,772116);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (540849,529058);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (777053,722935);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (87590,865648);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (672673,255589);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (979678,250461);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (119971,615065);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (926181,399488);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (302166,483823);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (921187,942112);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (410861,793261);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (238622,82673);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (391338,637711);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (939753,825503);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (505244,275359);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (815265,372812);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (757531,450449);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (933788,554808);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (484531,521151);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (218736,401405);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (650035,127466);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (725350,214925);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (646259,383554);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (539801,753135);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (646567,828840);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (472251,382024);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (806825,622288);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (965722,307670);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (862262,714220);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (892667,246593);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (916720,980041);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (161115,143956);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (471152,550254);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (302248,798988);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (988263,821145);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (461314,507018);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (540151,880502);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (463724,77476);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (335837,332747);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (878226,837252);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (175544,757865);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (249020,478782);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (128621,288482);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (918694,862227);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (981965,39503);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (113859,131140);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (255828,374642);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (215351,750977);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (833886,244259);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (384878,329837);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (504436,78850);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (969987,330802);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (959600,972581);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (359231,35258);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (49421,141232);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (209401,366561);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (337704,888940);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (216704,433436);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (256498,568088);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (853765,902473);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (406086,266756);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (744320,559099);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (797350,208064);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (597481,666410);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (83405,95820);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (873450,981215);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (77361,890825);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (602543,536697);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (103083,752214);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (29424,551039);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (975855,128223);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (4394,71407);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (659781,230732);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (293638,212661);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (898830,377976);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (230285,100159);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (368388,939803);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (378165,876052);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (144189,869834);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (130136,378413);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (535505,58917);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (412861,352611);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (579474,994250);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (919896,304270);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (743428,458537);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (544981,353214);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (632107,253559);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (937400,697764);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (746633,182533);
 
 
INSERT INTO task_estimation (tsk_id,est_id) VALUES (351282,548756);
 



 
INSERT INTO user_project (user_id,proj_id) VALUES ('CdFHTrJfbMbPRABKjsxgfQQ0i2qkUf',1);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('J6GgLhl2lQ6fJy8RqLvNTrGrM64CwEGFmjpyTQeA7x3nQwy',2);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('BUoTe2GZtGcVB',3);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('mKXa55YoJgiqxTmCxNz80D6TxkbX',4);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('1OZa3Pzwr3vuRwtrtckpPUUD53A8Z4nR',5);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('kmOBOQtabqSjgXpHwN4ZlLdLoXWQsbCIeksLdWEAfM7',6);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('G5N6ly5hlxyXEE368pSN7TOVMbkijUnIUoIRipRM',7);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('s',8);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('vjtioENlIxPfBDmze8FOgnR',9);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('3TYX8CkscINsiuyxSmQPWO2tsbDA2pV51U867ZC2e02LkHzm4',10);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('btrEjK4eBtX8RUen0fV270zzlVkzIW',11);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('viwN7ppuiWwbEG6tcXSh',12);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('h',13);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('YD63',14);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('T',15);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('O6hLXFOj8ynD5OWwLHL',16);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('a3BfjUuKwJ8otI0HIfUUUXsnZvi4TI4a1rHIB',17);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('AhIZ2LRp4MPqw5COnF0iwbonQ3JV4iMoIsc1FZY',18);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('sRrs8HQbYpynqwJqNoT6J2orq8ZtevyzYhtCdr',19);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('HADXugoRyZRps5qhRUrUPpEc20sKYlTcnkDSzgD6m22WMmL',20);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('2xF32mYSEdKq3LDI8VD',21);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('RMtBBuXotZEQfp4OBOHmiFF4gLpeR48idfG4wg05BcX',22);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('8x',23);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('FvJJY2vfmOm5wzr5IW0hv2hzTJTzIdVFL1d8B0AqvHKqWOiD',24);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('vPlEjsLWdl77bw0M1MDRiGwApbY6LGyPWU7',25);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('7o8xUGHePtzThFk0X6F4cwL00VgFmd8X1zW',26);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('GzIszSDDrezR48GyvqudYd1MfnVIM8N7z00',27);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('J0lFKKHiLkdCyAfLCpKIognaBRfD',28);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('H',29);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('qjSLbBZ8KcT0Fi1X1gExOHdY5FhoewwWrajdpjRYW4cIz2JSV',30);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('A',31);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('sDrWvkCRYb',32);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('57qC1LhFoFFADxPNZxLUZpe5spHFYc2zkJ3HMldkm3LpNfy',33);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('lrYMpGflxgVY4Vo1m1UyeIVKY7b5hQp8OdwHFxX3',34);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('KOoCem',35);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('W1wKxPqG',36);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('MNqmbfS6ZWVfj',37);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('0E3wzTd0ISCtVE6touGzmfWU',38);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('wxERNqUA1co57mzfkz1frLEEpNun56yoEcjF',39);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('Oh0UC68nKQg87pn',40);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('c6cp3RsjdDAiMPZxnlXgiTYQyPmv3ux',41);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('XPCRJLokbKA6AFMOnAJEYBFtU6Rg',42);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('T',43);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('dcSrpapGQJDTiufUW4lmkk7PZ4W4IMPQ',44);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('5D2NUygPkmE0TUemBM8Q7rSfoCtcJiTgNmfNa',45);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('E6g4YPJnoKl6NlcpyJ8bo1ImoGZubyG07fALRBkusUiP',46);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('1xnRXhYtYyjg33wwsNmYvcdwgYEo4Q7T',47);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('y2jvFoLLJqlK6VuvH51NEESHmBRN2SCE7By20eXsEW',48);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('K8l4EbN6bNnAiG7zyI',49);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('sKUkPyTJDGs6rWO',50);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('uwbRLjlFuGGzzW5eVoUYUypQGybnAvHnSpk',51);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('drJFuUTLZUrp474HZQ',52);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('kqUgoXXByKH22UKXPmi',53);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('PmNxslr38owFtAsFu501JeqfI3AgnG6FVLXG764BGKsbbhngJr',54);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('fEYdYBATXNlKGCHDnSfHg4TDwOAHlMDnH0n8a',55);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('6I8zSs5RN',56);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('zRVu5rJW1LtS18VKUSlKNamkEpKzic',57);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('ZHaHF4zEojX6wGus',58);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('RZpvzlTFLxIgUc0esAdcc7p',59);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('QlcXtGyzZUsOHiV6jD2ip7Zxq3e',60);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('Svi6AXd4hDxV4Y8Spa63TAcbZf0nLIsJkXNw4xjHwIxviY',61);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('npeLDNUxTKAFMQs6FsUVVT6',62);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('v2Qyc1',63);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('MRxx6AAUuodoofDCqQkqGJmzgWiB',64);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('8awKrOS',65);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('JtmZurn64kIzkVOyPH4VIDZGvW',66);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('560ImdUNalVQjjN8souO0Gj84n',67);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('VbY',68);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('1XFTZJCpyiBGB0EoMhTNnNIiUT3XtPz',69);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('h',70);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('j40RTybp1AFrSYoEACT3fuzhiXopOTrHOVPw',71);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('EPHBjUVGCoof5juue2ZsNpO5j5156IOExb3i8SI',72);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('om11IaY5LIbWnL08rMBmYYYBH',73);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('2W0Tm3kXDD',74);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('F',75);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('53vvxDqDaq6cHK',76);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('lnYgUPA',77);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('rYbkGj6aDGhpLEnGy0C',78);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('JrqfEhKRYmH2J08lApsf3eQIvOg1wkn4cYuQS',79);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('aDbwhhonaWcxXxRQe27TQxZOQYaS0PnZKfYAdpV',80);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('QPsR1qMOSltz5hdKNXzFcQS',81);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('uRyEyBSgLMH27XUPG',82);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('wpmv4GqslW1VyayEios6oMWGCYKas7GZqzj3',83);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('f2P6P3QZpc6EsEMYkEJH62BTG80ehISqeCwQspfOGTYVmAgQQ',84);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('1qWP',85);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('h5eg7UrVjZR',86);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('ftT6FmaRDK7QayyQS1qexYuNW1hgAVgUiHeUuP04',87);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('iJdP2HNXLD0FQEv',88);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('pzdbIZekutVdHuK6BY1iQUC7ayzhscc4vaOPhoEsryFgAxEAu5',89);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('VoClaqhrdF5qbG',90);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('DCtwsD3B7PG6PeRaZdv',91);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('HUGaZKwxnvzhhyeR0LGoJKOzd3IypTxdmDfuwwqFjGZVBft7n4',92);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('sXanZjKez0Qa2zlnYDWP3d5UHaE8Y7eokuPDRQLNoZc1wEXIrg',93);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('dyYFbxLHYRrot4JFiZau7',94);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('hpb6aUHDAmHojto0QxfZxJxMYipL',95);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('CSljzWIeEmkmqf6xvCtGQSFCEp6O2vY7OtX',96);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('3Vy4ZrlENnnlQ',97);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('RmPt4HIbbM0VdCeCtpO6x7',98);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('YpYSdjAublu60MTcTRbr1NSJceQYQTIKcUcpekz5wWZzo',99);
 
 
INSERT INTO user_project (user_id,proj_id) VALUES ('wDD',100);
 



